package stat;

import java.util.HashMap;
import java.util.TreeSet;

import component.event.ActionEvent;

public interface ActionEventObserver {
	public void update(ActionEvent markingEvent,
			HashMap<Integer, TreeSet<Integer>> updatedElements);
}
