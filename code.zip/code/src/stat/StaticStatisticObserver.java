package stat;

public interface StaticStatisticObserver {
	public void loadStatistic();
}
