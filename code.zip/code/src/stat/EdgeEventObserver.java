package stat;

import java.util.HashMap;
import java.util.TreeSet;

import component.graph.EdgeEvent;

public interface EdgeEventObserver {
	public void update(EdgeEvent edgeEvent,
			HashMap<Integer, TreeSet<Integer>> updatedElements);
}
