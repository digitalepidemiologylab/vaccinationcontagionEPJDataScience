package stat.twitter.edge;

import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

import model.Edge2RowException;
import model.SingleTypedNetworkEventModel;

import stat.StaticStatisticObserver;
import stat.StatisticException;

import component.graph.Edge;

public class NodeMatchSignedStatistic extends SignedEdgeStatistic implements
		StaticStatisticObserver {

	protected int[] nodeStatistics;

	public NodeMatchSignedStatistic(SingleTypedNetworkEventModel _data,
			int[][] _nodeStatistics, int _nodeStatIndex)
			throws StatisticException {
		super(_data);
		setStatisticData(_nodeStatistics, _nodeStatIndex);
	}

	public void setStatisticData(int[][] _nodeStatistics, int _nodeStatIndex) {
		if (_nodeStatistics != null) {
			nodeStatistics = new int[_nodeStatistics.length];
			for (int i = 0; i < nodeStatistics.length; i++)
				nodeStatistics[i] = _nodeStatistics[i][_nodeStatIndex];
		}
	}

	@Override
	public void loadStatistic() {
		try {
			double[][] statistics = getStatisticMatrix();
			int rowIndex = 0;
			for (Iterator<Edge> iter = data.getRows2EdgesIterator(); iter
					.hasNext(); rowIndex++) {
				Edge edge = iter.next();
				if (nodeStatistics[edge.senderID] == nodeStatistics[edge.receiverID])
					statistics[rowIndex][statIndex] = 1.0;
				else
					statistics[rowIndex][statIndex] = 0.0;
				//System.out.println(statistics[rowIndex][statIndex]);
			}
		} catch (Edge2RowException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(Object event,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		System.out.println("This " + this.getClass().getName()
				+ " class does not observe an event of "
				+ event.getClass().getName());
	}

}
