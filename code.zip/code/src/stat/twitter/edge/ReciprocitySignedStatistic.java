package stat.twitter.edge;

import java.util.HashMap;
import java.util.TreeSet;

import model.Edge2RowException;
import model.SingleTypedNetworkEventModel;

import stat.EdgeEventObserver;
import stat.StatisticException;
import utils.ArrayUtils;

import component.graph.EdgeEvent;

public class ReciprocitySignedStatistic extends SignedEdgeStatistic implements
		EdgeEventObserver {

	public ReciprocitySignedStatistic(SingleTypedNetworkEventModel _data)
			throws StatisticException {
		super(_data);
	}

	@Override
	public void update(EdgeEvent edgeEvent,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		double[][] statistics = getStatisticMatrix();
		int senderID = edgeEvent.senderID;
		int receiverID = edgeEvent.receiverID;
		if (data.currentGraph.edgeExist(receiverID, senderID)) {
			updateEdge(senderID, receiverID, statistics, updatedElements);
			updateEdge(receiverID, senderID, statistics, updatedElements);
		}
	}

	protected void updateEdge(int senderID, int receiverID,
			double[][] statistics,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		try {
			int rowIndex = data.getRowIndexOfEdge(senderID, receiverID);
			if (rowIndex >= 0) {
				statistics[rowIndex][statIndex] = 1;
				if (updatedElements != null)
					ArrayUtils.addNodalUpdatedNode(updatedElements, rowIndex,
							statIndex);
			}
		} catch (Edge2RowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void update(Object event,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		if (event instanceof EdgeEvent) {
			EdgeEvent edgeEvent = (EdgeEvent) event;
			update(edgeEvent, updatedElements);
		} else {
			System.out.println("This " + this.getClass().getName()
					+ " class does not observe an event of "
					+ event.getClass().getName());
		}
	}

}
