package stat.twitter.node;

import model.SingleTypedNetworkEventModel;
import model.twitter.TwitterModel;

import stat.Statistic;
import stat.StatisticException;

public abstract class SignedNodeStatistic extends Statistic {

	public SignedNodeStatistic(SingleTypedNetworkEventModel _data)
			throws StatisticException {
		super(_data);
		if (!(data instanceof TwitterModel))
			throw new StatisticException(data.getClass().getName()
					+ " must be used with TwitterModel!!!");
	}

	protected double[][] getStatisticMatrix() {
		return ((TwitterModel) data).currentNodeStatistics;
	}
}
