package stat.twitter.node;

import java.util.HashMap;
import java.util.TreeSet;

import model.SingleTypedNetworkEventModel;

import component.event.ActionEvent;

import stat.ActionEventObserver;
import stat.StatisticException;
import utils.ArrayUtils;

public class EventCountSignedStatistic extends SignedNodeStatistic implements
		ActionEventObserver {

	public EventCountSignedStatistic(SingleTypedNetworkEventModel _data)
			throws StatisticException {
		super(_data);
	}

	@Override
	public void update(ActionEvent markingEvent,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		double[][] statistics = getStatisticMatrix();
		statistics[markingEvent.nodeID][statIndex] += 1;
		if (updatedElements != null) {
			ArrayUtils.addNodalUpdatedNode(updatedElements,
					markingEvent.nodeID, statIndex);
		}
	}

	@Override
	public void update(Object event,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		if (event instanceof ActionEvent) {
			ActionEvent markingEvent = (ActionEvent) event;
			update(markingEvent, updatedElements);
		} else {
			System.out.println("This " + this.getClass().getName()
					+ " class does not observe an event of "
					+ event.getClass().getName());
		}
	}

}
