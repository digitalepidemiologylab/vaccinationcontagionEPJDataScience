package stat.twitter.node;

import java.util.HashMap;
import java.util.TreeSet;

import model.SingleTypedNetworkEventModel;

import stat.EdgeEventObserver;
import stat.StatisticException;
import utils.ArrayUtils;

import component.graph.EdgeEvent;

public class OutDegreeSignedStatistic extends SignedNodeStatistic implements
		EdgeEventObserver {

	public OutDegreeSignedStatistic(SingleTypedNetworkEventModel _data)
			throws StatisticException {
		super(_data);
	}

	@Override
	public void update(EdgeEvent edgeEvent,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		double[][] statistics = getStatisticMatrix();
		statistics[edgeEvent.senderID][statIndex] += 1;
		if (updatedElements != null)
			ArrayUtils.addNodalUpdatedNode(updatedElements, edgeEvent.senderID,
					statIndex);
	}

	@Override
	public void update(Object event,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		if (event instanceof EdgeEvent) {
			EdgeEvent edgeEvent = (EdgeEvent) event;
			update(edgeEvent, updatedElements);
		} else {
			System.out.println("This " + this.getClass().getName()
					+ " class does not observe an event of "
					+ event.getClass().getName());
		}
	}

}
