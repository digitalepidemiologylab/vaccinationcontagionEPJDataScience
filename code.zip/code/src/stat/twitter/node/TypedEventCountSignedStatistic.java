package stat.twitter.node;

import java.util.HashMap;
import java.util.TreeSet;

import model.SingleTypedNetworkEventModel;

import stat.ActionEventObserver;
import stat.StatisticException;
import utils.ArrayUtils;

import component.event.ActionEvent;

public class TypedEventCountSignedStatistic extends SignedNodeStatistic
		implements ActionEventObserver {

	protected int eventType;

	public TypedEventCountSignedStatistic(SingleTypedNetworkEventModel _data,
			int _eventType) throws StatisticException {
		super(_data);
		eventType = _eventType;
	}

	@Override
	public void update(ActionEvent markingEvent,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		if (markingEvent.type == eventType) {
			double[][] statistics = getStatisticMatrix();
			statistics[markingEvent.nodeID][statIndex] += 1;
			if (updatedElements != null) {
				ArrayUtils.addNodalUpdatedNode(updatedElements,
						markingEvent.nodeID, statIndex);
			}
		}
	}

	@Override
	public void update(Object event,
			HashMap<Integer, TreeSet<Integer>> updatedElements) {
		if (event instanceof ActionEvent) {
			ActionEvent markingEvent = (ActionEvent) event;
			update(markingEvent, updatedElements);
		} else {
			System.out.println("This " + this.getClass().getName()
					+ " class does not observe an event of "
					+ event.getClass().getName());
		}
	}

}
