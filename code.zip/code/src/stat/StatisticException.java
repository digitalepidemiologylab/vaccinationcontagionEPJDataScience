package stat;

public class StatisticException extends Exception {

	private static final long serialVersionUID = 9174793473624554715L;

	public StatisticException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StatisticException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StatisticException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public StatisticException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
}
