package stat;

import java.util.HashMap;
import java.util.TreeSet;

import model.SingleTypedNetworkEventModel;

public abstract class Statistic {
	protected int statIndex;
	protected SingleTypedNetworkEventModel data;

	public Statistic(SingleTypedNetworkEventModel _data) {
		data = _data;
	}

	public void setStatIndex(int _statIndex) {
		statIndex = _statIndex;
	}

	public int getStatIndex() {
		return statIndex;
	}

	public abstract void update(Object event,
			HashMap<Integer, TreeSet<Integer>> updatedElements);
	
	protected abstract double[][] getStatisticMatrix();
}
