package model.twitter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

import model.Edge2RowException;
import model.SingleTypedNetworkEventModel;

import component.cache.MatrixUpdateCache;
import component.event.ActionEvent;
import component.graph.DirectedEdge;
import component.graph.Edge;
import component.graph.EdgeListGraph;
import component.graph.EndNode;
import component.graph.EdgeEvent;
import data.DataReader;

import stat.EdgeEventObserver;
import stat.ActionEventObserver;
import stat.StaticStatisticObserver;
import stat.Statistic;
import stat.twitter.edge.SignedEdgeStatistic;
import stat.twitter.node.SignedNodeStatistic;

import utils.ArrayUtils;

public abstract class TwitterModel extends SingleTypedNetworkEventModel {

	// The element i of isPositivelyInfectious is true if node i is positively
	// infectious,
	// i.e. an positive event has occurred on her
	public boolean[] currentIsPositivelyInfectious;
	// This lists contains all current positively infectious node in the network
	public TreeSet<Integer> currentPositivelyInfectiousNodes;

	// The element i of isNegativelyInfectious is true if node i is negatively
	// infectious,
	// i.e. an negative event has occurred on her
	public boolean[] currentIsNegativelyInfectious;
	// This lists contains all current negatively infectious node in the network
	public TreeSet<Integer> currentNegativelyInfectiousNodes;

	// The current number of positive tweets on each node
	public int[] currentPositiveTweetCounts;
	// The current number of negative tweets on each node
	public int[] currentNegativeTweetCounts;
	// The current number of all tweets on each node
	public int[] currentAllTweetCounts;

	// The length of node covariates
	public int numOfNodeStatistics;
	// Node characteristic of each node, i.e.
	// nodeCovariates[i][1 -> K] is a K-covariate vector of node i
	public double[][] currentNodeStatistics;
	protected ArrayList<SignedNodeStatistic> nodeObserverStatistics;

	// The length K of edge covariates
	public int numOfEdgeStatistics;
	// edge covariate vectors from receiver to sender of the edge
	// [edgeID: senderID -> receiverID]
	public double[][] currentEdgeStatistics;
	protected ArrayList<SignedEdgeStatistic> edgeObserverStatistics;

	protected ArrayList<ActionEventObserver> actionEventObservers;
	protected ArrayList<EdgeEventObserver> edgeEventObservers;
	protected ArrayList<StaticStatisticObserver> staticStatisticObservers;

	// Cache data structures

	// This network event data is dirty, we must restart it before use.
	protected boolean dirty;

	// The current cache index. The 0 index corresponds to updates from
	// [firstEventTime, secondEventTime)
	protected int currentCacheIndex;

	protected EdgeListGraph beginningGraph;
	protected boolean[] beginningIsAtRisk;
	protected boolean[] beginningIsPositivelyInfectious;
	protected TreeSet<Integer> beginningPositivelyInfectiousNodes;
	protected boolean[] beginningIsNegativelyInfectious;
	protected TreeSet<Integer> beginningNegativelyInfectiousNodes;
	public int[] beginningPositiveTweetCounts;
	public int[] beginningNegativeTweetCounts;
	public int[] beginningAllTweetCounts;
	protected double[][] beginningNodeStatistics;
	protected double[][] beginningEdgeStatistics;

	// Node cache data
	MatrixUpdateCache nodeCache;

	// Edge cache data
	MatrixUpdateCache edgeCache;

	public TwitterModel(boolean _isRecurrent, String nodeTimesFilePath,
			String edgeTimesFilePath, String eventTimesFilePath,
			int _interestEventType, double _startingObservationTime,
			double _endingObservationTime, DataReader dataReader) {

		isRecurrent = _isRecurrent;

		interestEventType = _interestEventType;
		System.out.println("interestEventType = " + interestEventType);

		startingObservationTime = _startingObservationTime;
		System.out.println("startingObservationTime = "
				+ startingObservationTime);

		endingObservationTime = _endingObservationTime;
		System.out.println("endingObservationTime = " + endingObservationTime);

		dataReader.setNetworkEventModel(this);

		nodeTimes = new ArrayList<Double>();
		numOfNodes = dataReader.readNodeTimes(nodeTimesFilePath, nodeTimes);
		System.out.println("numOfNodes = " + numOfNodes);

		edgeTimes = new ArrayList<EdgeEvent>();
		numOfEdges = dataReader.readEdgeTimes(edgeTimesFilePath, edgeTimes);
		System.out.println("numOfEdges = " + numOfEdges);

		eventTimes = new ArrayList<ActionEvent>();
		interestEventTimes = new ArrayList<ActionEvent>();
		numOfEvents = dataReader.readEventTimes(eventTimesFilePath, eventTimes,
				interestEventTimes);
		numOfInterestEvents = interestEventTimes.size();
		System.out.println("numOfEvents = " + numOfEvents);
		System.out.println("numOfInterestEvents = " + numOfInterestEvents);
	}

	protected void initializeModelVariables() {

		System.out.println("TwitterModel::initializeModelVariables");

		// Friend Graph
		currentGraph = new EdgeListGraph(numOfNodes);

		// Status Vectors
		currentIsAtRisk = new boolean[numOfNodes];
		for (int i = 0; i < numOfNodes; i++)
			currentIsAtRisk[i] = false;

		currentIsPositivelyInfectious = new boolean[numOfNodes];
		currentIsNegativelyInfectious = new boolean[numOfNodes];
		for (int i = 0; i < numOfNodes; i++) {
			currentIsPositivelyInfectious[i] = false;
			currentIsNegativelyInfectious[i] = false;
		}
		currentPositivelyInfectiousNodes = new TreeSet<Integer>();
		currentNegativelyInfectiousNodes = new TreeSet<Integer>();

		currentPositiveTweetCounts = new int[numOfNodes];
		currentNegativeTweetCounts = new int[numOfNodes];
		currentAllTweetCounts = new int[numOfNodes];
		for (int i = 0; i < numOfNodes; i++) {
			currentPositiveTweetCounts[i] = 0;
			currentNegativeTweetCounts[i] = 0;
			currentAllTweetCounts[i] = 0;
		}

		// Data Structures for Cache
		comingNodes = new ArrayList<ArrayList<Integer>>(numOfInterestEvents);
		comingEdges = new ArrayList<ArrayList<DirectedEdge>>(
				numOfInterestEvents);
		updatedAtRiskNodes = new ArrayList<ArrayList<Integer>>(
				numOfInterestEvents);
	}

	// Use the data to build up time-saving cache structures for iterative
	// optimization methods
	public void createCachingData() {

		System.out.println("TwitterModel::createCachingData");

		initializeModelVariables();

		System.out.println("Updating static statistics");

		for (Iterator<StaticStatisticObserver> iter = staticStatisticObservers
				.iterator(); iter.hasNext();) {
			StaticStatisticObserver observer = iter.next();
			observer.loadStatistic();
		}

		System.out.println("Start rolling to the first event");

		// Roll every events to currentTime and update covariate matrices
		// and all other information respectively
		int nextInterestEventIndex = 0;
		double nextInterestEventTime = interestEventTimes
				.get(nextInterestEventIndex).timeStamp;

		System.out.println("nextInterestEventTime = " + nextInterestEventTime);

		// Roll nodes to right before nextEventTime
		int currentNodeEventIndex = 0;
		// Roll edges to right before nextEventTime
		int currentEdgeEventIndex = 0;
		// Roll events to right before nextEventTime
		int currentActionEventIndex = 0;
		while ((currentNodeEventIndex < nodeTimes.size() && nodeTimes
				.get(currentNodeEventIndex) < nextInterestEventTime)
				|| (currentEdgeEventIndex < edgeTimes.size() && edgeTimes
						.get(currentEdgeEventIndex).timeStamp < nextInterestEventTime)
				|| (currentActionEventIndex < eventTimes.size() && eventTimes
						.get(currentActionEventIndex).timeStamp < nextInterestEventTime)) {
			// get most recent times in future of node, edge, tweet events
			double nodeTime = (currentNodeEventIndex < nodeTimes.size()) ? nodeTimes
					.get(currentNodeEventIndex) : nextInterestEventTime;
			double edgeTime = (currentEdgeEventIndex < edgeTimes.size()) ? edgeTimes
					.get(currentEdgeEventIndex).timeStamp
					: nextInterestEventTime;
			double eventTime = (currentActionEventIndex < eventTimes.size()) ? eventTimes
					.get(currentActionEventIndex).timeStamp
					: nextInterestEventTime;
			// decide which kind of node, edge, or tweet events will be
			// processed next
			if (nodeTime <= edgeTime && nodeTime <= eventTime) {
				rollComingNodes(currentNodeEventIndex, false, null);
				currentNodeEventIndex++;
			} else if (edgeTime <= nodeTime && edgeTime <= eventTime) {
				rollComingEdges(currentEdgeEventIndex, false, null, null, null);
				currentEdgeEventIndex++;
			} else {
				rollActionEvents(currentActionEventIndex, false, null, null,
						null, null);
				currentActionEventIndex++;
			}
		}

		System.out.println("currentNodeEventIndex = " + currentNodeEventIndex);
		System.out.println("currentEdgeEventIndex = " + currentEdgeEventIndex);
		System.out.println("currentActionEventIndex = "
				+ currentActionEventIndex);

		System.out.println("Number of Positively Infected Nodes = "
				+ currentPositivelyInfectiousNodes.size());
		System.out.println("Number of Negatively Infected Nodes = "
				+ currentNegativelyInfectiousNodes.size());

		System.out.println("Finish rolling to the first event");

		// Take beginning snapshot
		takeVariablesSnapshot();

		System.out.println("Start rolling and caching events");

		// Roll events and cache updates
		for (nextInterestEventIndex = 1, currentCacheIndex = 0; nextInterestEventIndex <= numOfInterestEvents; nextInterestEventIndex++, currentCacheIndex++) {

			// Maps of nodes and edges which are updated during in the time
			// interval [t_{e-1}, t_e)
			HashMap<Integer, TreeSet<Integer>> updatedNodes = new HashMap<Integer, TreeSet<Integer>>();
			HashMap<Integer, TreeSet<Integer>> updatedEdges = new HashMap<Integer, TreeSet<Integer>>();

			// This list contains nodes which are recently positively infected
			// between two events of interest
			TreeSet<Integer> recentlyPositivelyInfectedNodes = new TreeSet<Integer>();
			// This list contains nodes which are recently negatively infected
			// between two events of interest
			TreeSet<Integer> recentlyNegativelyInfectedNodes = new TreeSet<Integer>();

			// Roll every events to right before nextEventTime and update
			// covariate matrices and all other information respectively
			if (nextInterestEventIndex < numOfInterestEvents)
				nextInterestEventTime = interestEventTimes
						.get(nextInterestEventIndex).timeStamp;
			else
				nextInterestEventTime = interestEventTimes
						.get(numOfInterestEvents - 1).timeStamp + 1.0;

			System.out.println("nextInterestEventTime = "
					+ nextInterestEventTime);

			ArrayList<Integer> myComingNodes = new ArrayList<Integer>();
			ArrayList<DirectedEdge> myComingEdges = new ArrayList<DirectedEdge>();
			while ((currentNodeEventIndex < nodeTimes.size() && nodeTimes
					.get(currentNodeEventIndex) < nextInterestEventTime)
					|| (currentEdgeEventIndex < edgeTimes.size() && edgeTimes
							.get(currentEdgeEventIndex).timeStamp < nextInterestEventTime)
					|| currentActionEventIndex < eventTimes.size()
					&& eventTimes.get(currentActionEventIndex).timeStamp < nextInterestEventTime) {
				// get most recent times in future of node, edge, tweet events
				double nodeTime = (currentNodeEventIndex < nodeTimes.size()) ? nodeTimes
						.get(currentNodeEventIndex) : nextInterestEventTime;
				double edgeTime = (currentEdgeEventIndex < edgeTimes.size()) ? edgeTimes
						.get(currentEdgeEventIndex).timeStamp
						: nextInterestEventTime;
				double eventTime = (currentActionEventIndex < eventTimes.size()) ? eventTimes
						.get(currentActionEventIndex).timeStamp
						: nextInterestEventTime;
				// decide which kind of node, edge, or tweet events will be
				// processed next
				if (nodeTime <= edgeTime && nodeTime <= eventTime) {
					// Roll nodes to nextEventTime and maintain those nodes
					// updated
					rollComingNodes(currentNodeEventIndex, true, myComingNodes);
					currentNodeEventIndex++;
				} else if (edgeTime <= nodeTime && edgeTime <= eventTime) {
					// Roll edges to nextEventTime and maintain those edges
					// updated
					rollComingEdges(currentEdgeEventIndex, true, updatedNodes,
							updatedEdges, myComingEdges);
					currentEdgeEventIndex++;
				} else {
					// Roll events to nextEventTime and maintain those nodes
					// updated
					rollActionEvents(currentActionEventIndex, true,
							updatedNodes, updatedEdges,
							recentlyPositivelyInfectedNodes,
							recentlyNegativelyInfectedNodes);
					currentActionEventIndex++;
				}
			}
			comingNodes.add(currentCacheIndex, myComingNodes);
			comingEdges.add(currentCacheIndex, myComingEdges);

			// Update cache structures based on maintain lists
			if (nodeCache != null)
				nodeCache.cacheMatrixUpdates(currentCacheIndex,
						currentNodeStatistics, updatedNodes);

			if (edgeCache != null)
				edgeCache.cacheMatrixUpdates(currentCacheIndex,
						currentEdgeStatistics, updatedEdges);

			// Find at-risk nodes whose intensities are changed
			TreeSet<Integer> myUpdatedAtRiskNodes = getUpdatedAtRiskNodes(
					myComingNodes, myComingEdges, updatedNodes, updatedEdges,
					recentlyPositivelyInfectedNodes,
					recentlyNegativelyInfectedNodes);
			updatedAtRiskNodes.add(currentCacheIndex, new ArrayList<Integer>(
					myUpdatedAtRiskNodes));

			System.out.println("Number of Positively Infected Nodes = "
					+ currentPositivelyInfectiousNodes.size());
			System.out.println("Number of Negatively Infected Nodes = "
					+ currentNegativelyInfectiousNodes.size());
		}

		endEventRolling();
		releaseRedundantData();
	}

	protected void rollComingNodes(int currentNodeEventIndex, boolean isCached,
			ArrayList<Integer> myComingNodes) {
		// System.out.println("in rollComingNodes()");
		// Update: currentIsAtRisk
		currentIsAtRisk[currentNodeEventIndex] = true;
		// Add the new node
		if (isCached)
			myComingNodes.add(currentNodeEventIndex);
	}

	protected void rollComingEdges(int currentEdgeEventIndex, boolean isCached,
			HashMap<Integer, TreeSet<Integer>> updatedNodes,
			HashMap<Integer, TreeSet<Integer>> updatedEdges,
			ArrayList<DirectedEdge> myComingEdges) {
		// System.out.println("in rollComingEdges()");
		EdgeEvent edgeEvent = edgeTimes.get(currentEdgeEventIndex);
		DirectedEdge directedEdge = new DirectedEdge(edgeEvent.senderID,
				edgeEvent.receiverID, currentEdgeEventIndex);
		// System.out.println("At time " + edgeEvent.timeStamp + ": "
		// + edgeEvent.senderID + " => " + edgeEvent.receiverID);
		if (isCached) {
			// Add the new edge
			myComingEdges.add(directedEdge);
			// Update: statistics who observe edge events (i.e. node
			// degrees)
			for (Iterator<EdgeEventObserver> it = edgeEventObservers.iterator(); it
					.hasNext();) {
				EdgeEventObserver observer = it.next();
				if (observer instanceof SignedNodeStatistic)
					observer.update(edgeEvent, updatedNodes);
				else if (observer instanceof SignedEdgeStatistic)
					observer.update(edgeEvent, updatedEdges);
				else
					System.out.println("Can not handle this kind of statistic "
							+ observer.getClass().getName());
			}
		} else
			// Update: statistics who observe edge events (i.e. node
			// degrees)
			for (Iterator<EdgeEventObserver> it = edgeEventObservers.iterator(); it
					.hasNext();) {
				EdgeEventObserver observer = it.next();
				observer.update(edgeEvent, null);
			}
		// Update: currentOutEdge, currentInEdges,
		currentGraph.addEdge(directedEdge);
	}

	protected void rollActionEvents(int currentActionEventIndex,
			boolean isCached, HashMap<Integer, TreeSet<Integer>> updatedNodes,
			HashMap<Integer, TreeSet<Integer>> updatedEdges,
			TreeSet<Integer> recentlyPositivelyInfectedNodes,
			TreeSet<Integer> recentlyNegativelyInfectedNodes) {
		// System.out.println("in rollActionEvents()");
		ActionEvent actionEvent = eventTimes.get(currentActionEventIndex);
		// Update: statistics who observe action events
		if (isCached) {
			for (Iterator<ActionEventObserver> it = actionEventObservers
					.iterator(); it.hasNext();) {
				ActionEventObserver observer = it.next();
				// System.out.println(observer.getClass().getName());
				if (observer instanceof SignedNodeStatistic)
					observer.update(actionEvent, updatedNodes);
				else if (observer instanceof SignedEdgeStatistic)
					observer.update(actionEvent, updatedEdges);
				else
					System.out.println("Can not handle this kind of statistic "
							+ observer.getClass().getName());
			}
		} else
			for (Iterator<ActionEventObserver> it = actionEventObservers
					.iterator(); it.hasNext();) {
				ActionEventObserver observer = it.next();
				observer.update(actionEvent, null);
			}

		if (actionEvent.type == interestEventType && !isRecurrent)
			currentIsAtRisk[actionEvent.nodeID] = false;

		// Update infectious status: currentIsInfectious, currentInfectiousNodes
		if (actionEvent.type > 0) {
			currentIsPositivelyInfectious[actionEvent.nodeID] = true;
			currentPositivelyInfectiousNodes.add(actionEvent.nodeID);
			if (recentlyPositivelyInfectedNodes != null)
				recentlyPositivelyInfectedNodes.add(actionEvent.nodeID);
		} else if (actionEvent.type < 0) {
			currentIsNegativelyInfectious[actionEvent.nodeID] = true;
			currentNegativelyInfectiousNodes.add(actionEvent.nodeID);
			if (recentlyNegativelyInfectedNodes != null)
				recentlyNegativelyInfectedNodes.add(actionEvent.nodeID);
		}

		// Update tweet counts
		if (actionEvent.type > 0)
			currentPositiveTweetCounts[actionEvent.nodeID] += 1;
		else if (actionEvent.type < 0)
			currentNegativeTweetCounts[actionEvent.nodeID] += 1;
		currentAllTweetCounts[actionEvent.nodeID] += 1;

		// store the event if it is required by the specific implementation
		storeEvent(actionEvent);
	}

	protected abstract void storeEvent(ActionEvent actionEvent);

	protected void takeVariablesSnapshot() {

		System.out.println("TwitterModel::takeVariablesSnapshot");

		// Friend Graph
		beginningGraph = new EdgeListGraph(currentGraph);

		// Status Vectors
		beginningIsAtRisk = new boolean[currentIsAtRisk.length];
		ArrayUtils.copyBooleanArray(currentIsAtRisk, beginningIsAtRisk);

		beginningIsPositivelyInfectious = new boolean[currentIsPositivelyInfectious.length];
		ArrayUtils.copyBooleanArray(currentIsPositivelyInfectious,
				beginningIsPositivelyInfectious);

		beginningIsNegativelyInfectious = new boolean[currentIsNegativelyInfectious.length];
		ArrayUtils.copyBooleanArray(currentIsNegativelyInfectious,
				beginningIsNegativelyInfectious);

		beginningPositivelyInfectiousNodes = new TreeSet<Integer>(
				currentPositivelyInfectiousNodes);

		beginningNegativelyInfectiousNodes = new TreeSet<Integer>(
				currentNegativelyInfectiousNodes);

		beginningPositiveTweetCounts = new int[numOfNodes];
		ArrayUtils.copyIntegerArray(currentPositiveTweetCounts,
				beginningPositiveTweetCounts);

		beginningNegativeTweetCounts = new int[numOfNodes];
		ArrayUtils.copyIntegerArray(currentNegativeTweetCounts,
				beginningNegativeTweetCounts);

		beginningAllTweetCounts = new int[numOfNodes];
		ArrayUtils.copyIntegerArray(currentAllTweetCounts,
				beginningAllTweetCounts);
	}

	protected TreeSet<Integer> getUpdatedAtRiskNodes(
			ArrayList<Integer> myComingNodes,
			ArrayList<DirectedEdge> myComingEdges,
			HashMap<Integer, TreeSet<Integer>> updatedNodes,
			HashMap<Integer, TreeSet<Integer>> updatedEdges,
			TreeSet<Integer> recentlyPositivelyInfectedNodes,
			TreeSet<Integer> recentlyNegativelyInfectedNodes) {

		// There are FIVE cases:

		// 1. An at-risk node whose node covariates are updated
		TreeSet<Integer> myUpdatedAtRiskNodes = new TreeSet<Integer>(
				updatedNodes.keySet());

		// 2. An at-risk node whose friends' node covariates are updated
		for (Iterator<Integer> it = updatedNodes.keySet().iterator(); it
				.hasNext();) {
			int updatedFriendID = it.next();
			if (currentGraph.inEdges.get(updatedFriendID) != null)
				for (Iterator<EndNode> nodeIt = currentGraph.inEdges.get(
						updatedFriendID).iterator(); nodeIt.hasNext();) {
					int updatedNodeID = nodeIt.next().nodeID;
					myUpdatedAtRiskNodes.add(updatedNodeID);
				}
		}

		// 3. An at-risk node sender of an edge whose covariates are updated
		for (Iterator<Integer> it = updatedEdges.keySet().iterator(); it
				.hasNext();) {
			int rowIndex = it.next();
			try {
				Edge edge = getEdgeOfRowIndex(rowIndex);
				myUpdatedAtRiskNodes.add(edge.senderID);
			} catch (Edge2RowException e) {
				e.printStackTrace();
			}
		}

		// 4. An at-risk node who has just made friends
		for (Iterator<DirectedEdge> it = myComingEdges.iterator(); it.hasNext();) {
			DirectedEdge edge = it.next();
			myUpdatedAtRiskNodes.add(edge.senderID);
		}

		// 5. Followers of the recently (positively or negatively) tweeting
		// nodes
		// Positive
		for (Iterator<Integer> positiveIter = recentlyPositivelyInfectedNodes
				.iterator(); positiveIter.hasNext();) {
			int recentlyInfectedNodeID = positiveIter.next();
			if (currentGraph.inEdges.get(recentlyInfectedNodeID) != null)
				for (Iterator<EndNode> nodeIt = currentGraph.inEdges.get(
						recentlyInfectedNodeID).iterator(); nodeIt.hasNext();) {
					int updatedNodeID = nodeIt.next().nodeID;
					myUpdatedAtRiskNodes.add(updatedNodeID);
				}
		}
		// Negative
		for (Iterator<Integer> negativeIter = recentlyNegativelyInfectedNodes
				.iterator(); negativeIter.hasNext();) {
			int recentlyInfectedNodeID = negativeIter.next();
			if (currentGraph.inEdges.get(recentlyInfectedNodeID) != null)
				for (Iterator<EndNode> nodeIt = currentGraph.inEdges.get(
						recentlyInfectedNodeID).iterator(); nodeIt.hasNext();) {
					int updatedNodeID = nodeIt.next().nodeID;
					myUpdatedAtRiskNodes.add(updatedNodeID);
				}
		}

		// However, we need to FILTER OUT THREE cases:
		// A. Note that new nodes between two events are not included in
		// these lists even their features are updated since they are being
		// taken are of in listOfComingNodes.
		for (Iterator<Integer> it = myComingNodes.iterator(); it.hasNext();)
			myUpdatedAtRiskNodes.remove(it.next());

		// B. Remove infectious nodes if we are working with a
		// non-recurrent setting.
		if (!isRecurrent)
			if (interestEventType > 0)
				for (Iterator<Integer> it = currentPositivelyInfectiousNodes
						.iterator(); it.hasNext();) {
					int removedNode = it.next();
					myUpdatedAtRiskNodes.remove(removedNode);
				}
			else if (interestEventType < 0)
				for (Iterator<Integer> it = currentNegativelyInfectiousNodes
						.iterator(); it.hasNext();) {
					int removedNode = it.next();
					myUpdatedAtRiskNodes.remove(removedNode);
				}

		// C. Remove nodes that are not at risk since their statistics are still
		// updated for being used later.
		TreeSet<Integer> removedNodes = new TreeSet<Integer>();
		for (Iterator<Integer> it = myUpdatedAtRiskNodes.iterator(); it
				.hasNext();) {
			int nodeID = it.next();
			if (!currentIsAtRisk[nodeID]) {
				removedNodes.add(nodeID);
			}
		}

		// remove all nodes fall into A, B, or C
		myUpdatedAtRiskNodes.removeAll(removedNodes);

		return myUpdatedAtRiskNodes;
	}

	// Clean up all unnecessary data and mainly rely on cache structures
	protected void releaseRedundantData() {

		System.out.println("TwitterModel::releaseRedundantData");

		// information is in currentIsAtRisk
		nodeTimes = null;

		// information is in currentOutEdges and currentInEdges
		edgeTimes = null;

		// information is in covariate matrices
		eventTimes = null;
	}

	// start the rolling over events of interest
	public void startEventRolling() {

		System.out.println("TwitterModel::startEventRolling");

		if (dirty) {

			currentGraph = new EdgeListGraph(beginningGraph);

			ArrayUtils.copyBooleanArray(beginningIsAtRisk, currentIsAtRisk);

			ArrayUtils.copyBooleanArray(beginningIsPositivelyInfectious,
					currentIsPositivelyInfectious);

			ArrayUtils.copyBooleanArray(beginningIsNegativelyInfectious,
					currentIsNegativelyInfectious);

			currentPositivelyInfectiousNodes = new TreeSet<Integer>(
					beginningPositivelyInfectiousNodes);

			currentNegativelyInfectiousNodes = new TreeSet<Integer>(
					beginningNegativelyInfectiousNodes);

			ArrayUtils.copyIntegerArray(beginningPositiveTweetCounts,
					currentPositiveTweetCounts);

			ArrayUtils.copyIntegerArray(beginningNegativeTweetCounts,
					currentNegativeTweetCounts);

			ArrayUtils.copyIntegerArray(beginningAllTweetCounts,
					currentAllTweetCounts);

			ArrayUtils.copyDoubleMatrix(beginningNodeStatistics,
					currentNodeStatistics);

			ArrayUtils.copyDoubleMatrix(beginningEdgeStatistics,
					currentEdgeStatistics);

			dirty = false;
			currentCacheIndex = 0;
		}
	}

	public int getCurrentCacheIndex() {
		return currentCacheIndex;
	}

	// Get the current event which contains data on who, what, and when of the
	// event in consideration
	public ActionEvent getCurrentEvent() {
		return interestEventTimes.get(currentCacheIndex);
	}

	// Update all information from the current event time to the time right
	// before the next event time and then roll to the next event
	public void rollToNextEvent() {
		ActionEvent event = interestEventTimes.get(currentCacheIndex);

		// Update atRisk information, i.e currentIsAtRisk
		for (Iterator<Integer> it = comingNodes.get(currentCacheIndex)
				.iterator(); it.hasNext();) {
			int nodeID = it.next();
			currentIsAtRisk[nodeID] = true;
		}

		// Update edges, i.e currentOutEdges and currentInEdges;
		for (Iterator<DirectedEdge> it = comingEdges.get(currentCacheIndex)
				.iterator(); it.hasNext();) {
			DirectedEdge edge = it.next();
			currentGraph.addEdge(edge);
		}

		if (!isRecurrent)
			currentIsAtRisk[event.nodeID] = false;

		// Update infectious information:
		// currentIsPositivelyInfectious and currentPositivelyInfectiousNodes
		// OR
		// currentIsNegativelyInfectious and currentNegativelyInfectiousNodes
		if (event.type > 0) {
			currentIsPositivelyInfectious[event.nodeID] = true;
			currentPositivelyInfectiousNodes.add(event.nodeID);
		} else if (event.type < 0) {
			currentIsNegativelyInfectious[event.nodeID] = true;
			currentNegativelyInfectiousNodes.add(event.nodeID);
		}

		// Update tweet counts
		if (event.type > 0)
			currentPositiveTweetCounts[event.nodeID] += 1;
		else if (event.type < 0)
			currentNegativeTweetCounts[event.nodeID] += 1;
		currentAllTweetCounts[event.nodeID] += 1;

		// Update susceptible statistics, i.e. currentNodeCovariates, using
		// cache
		updateNodeStatisticsFromCache();

		// Update edge statistics, i.e. currentEdgeCovariates, using cache
		updateEdgeStatisticsFromCache();

		currentCacheIndex++;
	}

	// update node statistics, i.e. currentNodeStatistics, using cache
	protected abstract void updateNodeStatisticsFromCache();

	// update edge statistics, i.e. currentEdgeStatistics, using cache
	protected abstract void updateEdgeStatisticsFromCache();

	// finish the rolling over events of interest
	public void endEventRolling() {
		System.out.println("TwitterModel::endEventRolling");
		dirty = true;
	}

	// print some summary information about cache data structures
	public void cacheSummary() {
		System.out.println("Cache size is " + updatedAtRiskNodes.size());
		for (int i = 0; i < updatedAtRiskNodes.size(); i++)
			System.out.print(updatedAtRiskNodes.get(i).size() + "\t");
		System.out.println();
	}

	public void summaryStatistics() {

		if (nodeObserverStatistics != null) {
			System.out.println("Number of node statistics is "
					+ nodeObserverStatistics.size());
			for (int k = 0; k < nodeObserverStatistics.size(); k++)
				System.out.println("Statistic " + k + ": "
						+ nodeObserverStatistics.get(k).getClass().getName()
						+ " has index "
						+ nodeObserverStatistics.get(k).getStatIndex());
		}

		if (edgeObserverStatistics != null) {
			System.out.println("Number of edge statistics is "
					+ edgeObserverStatistics.size());
			for (int k = 0; k < edgeObserverStatistics.size(); k++)
				System.out.println("Statistic " + k + ": "
						+ edgeObserverStatistics.get(k).getClass().getName()
						+ " has index "
						+ edgeObserverStatistics.get(k).getStatIndex());
		}
	}

	// Handling flexible statistics using Observer Design Pattern
	protected void registerEventObserver(Statistic statistic) {
		if (statistic instanceof EdgeEventObserver) {
			edgeEventObservers.add((EdgeEventObserver) statistic);
			System.out.println("An EdgeEventObserver is added");
		}
		if (statistic instanceof ActionEventObserver) {
			actionEventObservers.add((ActionEventObserver) statistic);
			System.out.println("An ActionEventObserver is added");
		}
		if (statistic instanceof StaticStatisticObserver) {
			staticStatisticObservers.add((StaticStatisticObserver) statistic);
			System.out.println("An StaticStatisticObserver is added");
		}
		if (!(statistic instanceof EdgeEventObserver)
				&& !(statistic instanceof ActionEventObserver)
				&& !(statistic instanceof StaticStatisticObserver))
			System.out
					.println("This"
							+ statistic.getClass().getName()
							+ "node statistic can not not handle edge or action events or static covariates");
	}

	public void addNodeStatistic(SignedNodeStatistic nodeStatistic) {
		System.out.println("Adding " + nodeStatistic.getClass().getName());
		nodeStatistic.setStatIndex(nodeObserverStatistics.size());
		nodeObserverStatistics.add(nodeStatistic);
		registerEventObserver(nodeStatistic);
		numOfNodeStatistics++;
	}

	public void addEdgeStatistic(SignedEdgeStatistic edgeStatistic) {
		System.out.println("Adding " + edgeStatistic.getClass().getName());
		edgeStatistic.setStatIndex(edgeObserverStatistics.size());
		edgeObserverStatistics.add(edgeStatistic);
		registerEventObserver(edgeStatistic);
		numOfEdgeStatistics++;
	}
}
