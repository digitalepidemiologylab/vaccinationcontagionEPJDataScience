package model.twitter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.collections.keyvalue.MultiKey;

import stat.EdgeEventObserver;
import stat.ActionEventObserver;
import stat.StaticStatisticObserver;
import stat.twitter.edge.SignedEdgeStatistic;
import stat.twitter.node.SignedNodeStatistic;
import utils.ArrayUtils;

import model.Edge2RowException;
import model.ModelException;

import component.cache.MatrixUpdateCache;
import component.event.NodeEvent;
import component.event.ByActorActionEvent;
import component.event.ActionEvent;
import component.graph.Edge;

import data.DataReader;

public class EdgeTwitterModel extends TwitterModel {

	// map from edges to rows
	protected HashMap<MultiKey, Integer> edges2RowsMap;
	protected ArrayList<Edge> rows2EdgesMap;

	public EdgeTwitterModel(boolean _isRecurrent,
			String nodeTimesFilePath, String edgeTimesFilePath,
			String eventTimesFilePath, int _interestEventType,
			double _startingObservationTime, double _endingObservationTime,
			DataReader dataReader) {
		super(_isRecurrent, nodeTimesFilePath, edgeTimesFilePath,
				eventTimesFilePath, _interestEventType,
				_startingObservationTime, _endingObservationTime, dataReader);

		// Listeners for Statistics

		edgeEventObservers = new ArrayList<EdgeEventObserver>();

		actionEventObservers = new ArrayList<ActionEventObserver>();

		staticStatisticObservers = new ArrayList<StaticStatisticObserver>();

		nodeObserverStatistics = new ArrayList<SignedNodeStatistic>();
		numOfNodeStatistics = 0;

		edgeObserverStatistics = new ArrayList<SignedEdgeStatistic>();
		numOfEdgeStatistics = 0;
	}

	protected void initializeModelVariables() {

		super.initializeModelVariables();

		System.out
				.println("MemorylessEdgeSignedSTNEModel::takeVariablesSnapshot");

		// Matrices of Statistics
		currentNodeStatistics = new double[numOfNodes][numOfNodeStatistics];
		ArrayUtils.resetDoubleMatrix(currentNodeStatistics);

		currentEdgeStatistics = new double[numOfEdges][numOfEdgeStatistics];
		ArrayUtils.resetDoubleMatrix(currentEdgeStatistics);

		// Data Structures for Cache
		nodeCache = new MatrixUpdateCache(numOfInterestEvents);

		edgeCache = new MatrixUpdateCache(numOfInterestEvents);
	}

	protected void takeVariablesSnapshot() {

		super.takeVariablesSnapshot();

		System.out
				.println("MemorylessEdgeSignedSTNEModel::takeVariablesSnapshot");

		// Matrices of Statistics

		beginningNodeStatistics = new double[numOfNodes][numOfNodeStatistics];
		ArrayUtils.copyDoubleMatrix(currentNodeStatistics,
				beginningNodeStatistics);

		beginningEdgeStatistics = new double[numOfEdges][numOfEdgeStatistics];
		ArrayUtils.copyDoubleMatrix(currentEdgeStatistics,
				beginningEdgeStatistics);
	}

	@Override
	protected void storeEvent(ActionEvent markingEvent) {
	}

	@Override
	protected void updateNodeStatisticsFromCache() {
		nodeCache.updateMatrix(currentCacheIndex, currentNodeStatistics);
	}

	@Override
	protected void updateEdgeStatisticsFromCache() {
		edgeCache.updateMatrix(currentCacheIndex, currentEdgeStatistics);
	}

	public Iterator<Edge> getRows2EdgesIterator() throws Edge2RowException {
		return rows2EdgesMap.iterator();
	}

	@Override
	public void initializeEdge2RowMap(int numOfEdges) {
		edges2RowsMap = new HashMap<MultiKey, Integer>();
		rows2EdgesMap = new ArrayList<Edge>(numOfEdges);
		for (int i = 0; i < numOfEdges; i++)
			rows2EdgesMap.add(i, null);
	}

	@Override
	public void updateEdge2RowMap(int senderID, int receiverID, int rowID) {
		edges2RowsMap.put(new MultiKey(senderID, receiverID), rowID);
		rows2EdgesMap.set(rowID, new Edge(senderID, receiverID));
	}

	@Override
	public int getRowIndexOfEdge(int senderID, int receiverID)
			throws Edge2RowException {
		MultiKey key = new MultiKey(senderID, receiverID);
		if (edges2RowsMap.containsKey(key)) {
			return edges2RowsMap.get(key);
		} else
			return -1;
	}

	@Override
	public Edge getEdgeOfRowIndex(int rowIndex) throws Edge2RowException {
		if (rowIndex < rows2EdgesMap.size())
			return rows2EdgesMap.get(rowIndex);
		else
			throw new Edge2RowException("Out of bound row index!!!");
	}

	@Override
	public ArrayList<ByActorActionEvent> getEventsOnNode(int nodeID)
			throws ModelException {
		throw new ModelException(
				"This getEventsOfType(int type) method is not supported by "
						+ this.getClass().getName());
	}

	@Override
	public ArrayList<NodeEvent> getEventsOfType(int type)
			throws ModelException {
		throw new ModelException(
				"This getEventsOfType(int type) method is not supported by "
						+ this.getClass().getName());
	}

}
