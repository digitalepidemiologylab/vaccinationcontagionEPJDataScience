package model;

import java.io.PrintWriter;

public interface NestedCaseControlSampler {

	// print statistics of a row into a file
	public void outputStatistics2File(PrintWriter outputFile, int index,
			double eventTime, int rowIndex, boolean isEvent);

	// get nested case-control samples, i.e for each event we record
	// statistics of the event node as well as statistics of sampleRatio
	// non-event nodes which are at-risk at that time
	public void sampleCaseControlData(PrintWriter outputFile,
			double sampleRatio, long seed);

}
