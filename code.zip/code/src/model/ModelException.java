package model;

public class ModelException extends Exception {

	private static final long serialVersionUID = -216182267170555591L;

	public ModelException() {
		// TODO Auto-generated constructor stub
	}

	public ModelException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ModelException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ModelException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
