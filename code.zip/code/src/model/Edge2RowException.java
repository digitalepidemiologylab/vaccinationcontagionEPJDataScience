package model;

public class Edge2RowException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1301654145050853823L;

	public Edge2RowException() {
		// TODO Auto-generated constructor stub
	}

	public Edge2RowException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public Edge2RowException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public Edge2RowException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
