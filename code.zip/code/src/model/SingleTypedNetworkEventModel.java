package model;

import java.util.ArrayList;
import java.util.Iterator;

import component.event.NodeEvent;
import component.event.ByActorActionEvent;
import component.event.ActionEvent;
import component.graph.DirectedEdge;
import component.graph.Edge;
import component.graph.EdgeEvent;
import component.graph.EdgeListGraph;

public abstract class SingleTypedNetworkEventModel {

	// True if the data model is recurrent. For a recurrent model, node is still
	// at risk
	// even it is infected before
	public boolean isRecurrent;

	// The total number of nodes in the social network at the end of observation
	// time
	public int numOfNodes;

	// The list of node observation times in time ordering. Elements are indexed
	// by nodeIDs
	// nodeObservationTimes[i] is the observation time of node i
	protected ArrayList<Double> nodeTimes;

	// The total number of edges in the social network at the end of observation
	// time
	public int numOfEdges;

	// The list of edge observation times in time ordering. Elements are indexed
	// by edgeIDs
	// edgeObservationTimes[i] contains the observation time, senderID, and
	// receiverID of edge i
	protected ArrayList<EdgeEvent> edgeTimes;

	// The total number of events (all kind of events)
	public int numOfEvents;

	// The list of events in time ordering
	protected ArrayList<ActionEvent> eventTimes;

	public EdgeListGraph currentGraph;

	public boolean[] currentIsAtRisk;

	// The event type of interest
	public int interestEventType;

	// The starting observation time
	public double startingObservationTime;

	// The ending observation time
	public double endingObservationTime;

	public int numOfInterestEvents;
	// The sequence of events of interest
	// sequenceOfEvents[i] is the index of the interest event i
	// in the all-type event array events
	public ArrayList<ActionEvent> interestEventTimes;

	// The element at 0 index corresponds to a list of nodes coming from the
	// first event of interest to right before the second event of interest
	public ArrayList<ArrayList<Integer>> comingNodes;

	// The element at 0 index corresponds to a list of edges coming from the
	// first event of interest to right before the second event of interest
	public ArrayList<ArrayList<DirectedEdge>> comingEdges;

	// The element at 0 index corresponds to a list of nodes whose intensities
	// are changed during the time interval from the first event of interest to
	// right before the second event of interest
	public ArrayList<ArrayList<Integer>> updatedAtRiskNodes;

	// Access to edge-2-row map
	public abstract void initializeEdge2RowMap(int numOfEdges)
			throws Edge2RowException;

	public abstract void updateEdge2RowMap(int senderID, int receiveriD,
			int rowID) throws Edge2RowException;

	public abstract int getRowIndexOfEdge(int senderID, int receiverID)
			throws Edge2RowException;

	public abstract Edge getEdgeOfRowIndex(int rowIndex)
			throws Edge2RowException;

	public abstract Iterator<Edge> getRows2EdgesIterator()
			throws Edge2RowException;

	// Access event history
	public abstract ArrayList<ByActorActionEvent> getEventsOnNode(int nodeID)
			throws ModelException;

	public abstract ArrayList<NodeEvent> getEventsOfType(int type)
			throws ModelException;

	public double getStartingObservationTime() {
		return startingObservationTime;
	}

	// Access variables
	public double getEndingObservationTime() {
		return endingObservationTime;
	}

	// start the rolling over events of interest
	public abstract void startEventRolling();

	public abstract int getCurrentCacheIndex();

	// get the current event which contains data on who, what, and when of the
	// event in consideration
	public abstract ActionEvent getCurrentEvent();

	// update all information from the current event time to the time right
	// before the next event time and then roll to the next event
	public abstract void rollToNextEvent();

	// finish the rolling over events of interest
	public abstract void endEventRolling();

	// print some summary information about cache data structures
	public abstract void cacheSummary();

	public abstract void summaryStatistics();

	public abstract void createCachingData();

}
