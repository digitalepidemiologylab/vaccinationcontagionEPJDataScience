package exp.twitter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.text.DecimalFormat;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.StringTokenizer;

import model.twitter.TwitterModel;
import model.twitter.EdgeTwitterModel;

import data.DataReader;
import data.TwitterDataReader;
import data.Tweet;

import estimator.TwitterStatisticMap;
import estimator.sampler.EdgeTwitterSampler;
import estimator.sampler.TwitterSampler;

import stat.twitter.node.InDegreeSignedStatistic;
import stat.twitter.node.OutDegreeSignedStatistic;
import stat.twitter.node.TypedEventCountSignedStatistic;
import stat.twitter.node.EventCountSignedStatistic;

import stat.twitter.edge.ReciprocitySignedStatistic;
import stat.twitter.edge.SharedFollowersSignedStatistic;
import stat.twitter.edge.SharedFriendsSignedStatistic;

public class TwitterMisclassificationExperiment {

	public static ArrayList<Tweet> allTweets;
	public static int irrTweets;
	public static int posTweets;
	public static int negTweets;
	public static int neuTweets;

	// 0 'I': {'I': 190, '+': 1, '-': 1, 'O': 12},
	// 1 '+': {'I': 9, '+': 27, '-': 1, 'O': 18},
	// 2 '-': {'I': 5, '+': 1, '-': 26, 'O': 19},
	// 3 'O': {'I': 16, '+': 10, '-': 6, 'O': 288}

	// The mis-classification table computed from the training data for tweet
	// classification
	public static int[][] errorTable = { { 190, 1, 1, 12 }, { 9, 27, 1, 18 },
			{ 5, 1, 26, 19 }, { 16, 10, 6, 288 } };

	// The toggle probability table which is the transposed version of the
	// toggle matrix in the supplementary note
	public static double[][] toggleProbs = {
			{ 0.73795038, 0.09478150, 0.04138917, 0.1258790 },
			{ 0.01035221, 0.75788695, 0.02206359, 0.2096972 },
			{ 0.01402940, 0.03804055, 0.77741997, 0.1705101 },
			{ 0.01752638, 0.07128384, 0.05914360, 0.8520462 } };

	// Read all tweets from the file
	public static void readAllEventFile(String allTweetsFilePath,
			ArrayList<Tweet> allTweets) {

		try {

			irrTweets = 0;
			posTweets = 0;
			negTweets = 0;
			neuTweets = 0;

			allTweets.clear();

			BufferedReader reader = new BufferedReader(new FileReader(new File(
					allTweetsFilePath)));

			String line = null;
			int counter = 0;

			// ignore the first line: the total number of tweets
			reader.readLine();

			while ((line = reader.readLine()) != null) {

				counter++;
				if (counter % 10000 == 0)
					System.out.println("Processing up to the event " + counter);

				StringTokenizer tokenizer = new StringTokenizer(line.trim(),
						"\t");

				double time = Double.parseDouble(tokenizer.nextToken().trim());

				int user = Integer.parseInt(tokenizer.nextToken().trim());

				short attitude = Short.parseShort(tokenizer.nextToken().trim());
				switch (attitude) {
				case -10:
					irrTweets++;
					break;
				case +1:
					posTweets++;
					break;
				case -1:
					negTweets++;
					break;
				case 0:
					neuTweets++;
					break;
				}

				Tweet tweet = new Tweet(time, user, attitude);
				allTweets.add(tweet);

			}

			System.out.println("The total number of tweets is "
					+ allTweets.size());

			System.out.println("The total number of IRRELEVANT tweets is "
					+ irrTweets);

			System.out.println("The total number of POSITIVE tweets is "
					+ posTweets);

			System.out.println("The total number of NEGATIVE tweets is "
					+ negTweets);

			System.out.println("The total number of NEUTRAL tweets is "
					+ neuTweets);

			reader.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Obtain the toggled label of a tweet
	public static short toggleAttitude(int labelIndex, Random randomizer) {

		short attitude;

		double u = randomizer.nextDouble();

		if (u < toggleProbs[labelIndex][0])
			attitude = -10;
		else if (u < (toggleProbs[labelIndex][0] + toggleProbs[labelIndex][1]))
			attitude = +1;
		else if (u < (toggleProbs[labelIndex][0] + toggleProbs[labelIndex][1] + toggleProbs[labelIndex][2]))
			attitude = -1;
		else
			attitude = 0;

		return attitude;

	}

	// Generate toggled tweet data sets
	public static String getNoiseRelevantFile(ArrayList<Tweet> allTweets,
			String outputDirectory, int sampleIndex, int eventType) {

		String outSubDir;
		if (eventType == -1)
			outSubDir = "neg";
		else
			outSubDir = "pos";
		if (!(new File(outputDirectory + "/" + outSubDir)).exists()) {
			(new File(outputDirectory + "/" + outSubDir)).mkdir();
		}

		String outputFile = outputDirectory + "/" + outSubDir + "/events_"
				+ sampleIndex + ".txt";

		String outputStatsFile = outputDirectory + "/" + outSubDir
				+ "/dataStatistics_" + sampleIndex + ".txt";

		try {

			int irrTweets = 0;
			int posTweets = 0;
			int negTweets = 0;
			int neuTweets = 0;

			// Create the randomizer
			Random randomizer = new Random(sampleIndex);

			// Toggle labels and collect relevant tweets
			ArrayList<Tweet> relevantTweets = new ArrayList<Tweet>();

			for (int i = 0; i < allTweets.size(); i++) {

				Tweet tweet = allTweets.get(i);

				switch (tweet.attitude) {
				case -10:
					tweet.attitude = toggleAttitude(0, randomizer);
					break;
				case +1:
					tweet.attitude = toggleAttitude(1, randomizer);
					break;
				case -1:
					tweet.attitude = toggleAttitude(2, randomizer);
					break;
				case 0:
					tweet.attitude = toggleAttitude(3, randomizer);
					break;
				}

				// If the toggled tweet is relevant then collect it
				if (tweet.attitude == +1 || tweet.attitude == -1
						|| tweet.attitude == 0)
					relevantTweets.add(tweet);

				// Compute summary statistics
				switch (tweet.attitude) {
				case -10:
					irrTweets++;
					break;
				case +1:
					posTweets++;
					break;
				case -1:
					negTweets++;
					break;
				case 0:
					neuTweets++;
					break;
				}
			}

			// Write out relevant tweets
			DecimalFormat outputDateFormatter = new DecimalFormat(".0000000000");
			PrintWriter writer = new PrintWriter(new BufferedWriter(
					new FileWriter(new File(outputFile))));
			writer.write(relevantTweets.size() + "\n");
			for (Iterator<Tweet> it = relevantTweets.iterator(); it.hasNext();) {
				Tweet tweet = it.next();
				writer.write(outputDateFormatter.format(tweet.time) + "\t"
						+ tweet.userID + "\t" + tweet.attitude + "\n");
			}
			writer.close();

			// Write summary statistics to the file
			PrintWriter statsWriter = new PrintWriter(new BufferedWriter(
					new FileWriter(new File(outputStatsFile), true)));
			statsWriter.println(eventType + "\t" + sampleIndex + "\t"
					+ irrTweets + "\t" + posTweets + "\t" + negTweets + "\t"
					+ neuTweets);
			statsWriter.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return outputFile;
	}

	public static String getCaseControlSamplingFile(String nodeTimesFilePath,
			String edgeTimesFilePath, String eventTimesFilePath, int eventType,
			double startingObservationTime, double endingObservationTime,
			String outputDirectory, double controlSampleSize, int sampleIndex)
			throws Exception {

		String outSubDir;
		if (eventType == -1)
			outSubDir = "neg";
		else
			outSubDir = "pos";
		if (!(new File(outputDirectory + "/" + outSubDir)).exists()) {
			(new File(outputDirectory + "/" + outSubDir)).mkdir();
		}

		String outputFile = outputDirectory + "/" + outSubDir + "/samples_"
				+ sampleIndex + ".txt";

		DataReader dataReader = new TwitterDataReader();

		TwitterModel data = new EdgeTwitterModel(true, nodeTimesFilePath,
				edgeTimesFilePath, eventTimesFilePath, eventType,
				startingObservationTime, endingObservationTime, dataReader);

		// Add statistics to data object
		System.out.println("Adding statistics to the model");
		TwitterStatisticMap statisticMap = new TwitterStatisticMap();

		// Node statistics
		System.out.println("Adding NODE statistics to the model");

		EventCountSignedStatistic tweetCountStat = new EventCountSignedStatistic(
				data);
		data.addNodeStatistic(tweetCountStat);
		statisticMap.addSusceptibleStatistics(tweetCountStat);
		statisticMap.addFriendNodeStatistics(tweetCountStat);

		TypedEventCountSignedStatistic posTweetCountStat = new TypedEventCountSignedStatistic(
				data, +1);
		data.addNodeStatistic(posTweetCountStat);
		if (data.interestEventType == +1)
			statisticMap.addSusceptibleStatistics(posTweetCountStat);
		statisticMap.addPositiveNodeStatistics(posTweetCountStat);

		TypedEventCountSignedStatistic negTweetCountStat = new TypedEventCountSignedStatistic(
				data, -1);
		data.addNodeStatistic(negTweetCountStat);
		if (data.interestEventType == -1)
			statisticMap.addSusceptibleStatistics(negTweetCountStat);
		statisticMap.addNegativeNodeStatistics(negTweetCountStat);

		InDegreeSignedStatistic inDegreeStat = new InDegreeSignedStatistic(data);
		data.addNodeStatistic(inDegreeStat);
		statisticMap.addSusceptibleStatistics(inDegreeStat);
		statisticMap.addPositiveNodeStatistics(inDegreeStat);
		statisticMap.addNegativeNodeStatistics(inDegreeStat);
		statisticMap.addFriendNodeStatistics(inDegreeStat);

		OutDegreeSignedStatistic outDegreeStat = new OutDegreeSignedStatistic(
				data);
		data.addNodeStatistic(outDegreeStat);
		statisticMap.addPositiveNodeStatistics(outDegreeStat);
		statisticMap.addNegativeNodeStatistics(outDegreeStat);
		statisticMap.addFriendNodeStatistics(outDegreeStat);

		// Edge statistics
		System.out.println("Adding EDGE statistics to the model");

		ReciprocitySignedStatistic reciprocityStat = new ReciprocitySignedStatistic(
				data);
		data.addEdgeStatistic(reciprocityStat);
		statisticMap.addPositiveEdgeStatistics(reciprocityStat);
		statisticMap.addNegativeEdgeStatistics(reciprocityStat);
		statisticMap.addFriendEdgeStatistics(reciprocityStat);

		SharedFollowersSignedStatistic sharedFollowersStat = new SharedFollowersSignedStatistic(
				data);
		data.addEdgeStatistic(sharedFollowersStat);
		statisticMap.addPositiveEdgeStatistics(sharedFollowersStat);
		statisticMap.addNegativeEdgeStatistics(sharedFollowersStat);
		statisticMap.addFriendEdgeStatistics(sharedFollowersStat);

		SharedFriendsSignedStatistic sharedFriendsStat = new SharedFriendsSignedStatistic(
				data);
		data.addEdgeStatistic(sharedFriendsStat);
		statisticMap.addPositiveEdgeStatistics(sharedFriendsStat);
		statisticMap.addNegativeEdgeStatistics(sharedFriendsStat);
		statisticMap.addFriendEdgeStatistics(sharedFriendsStat);

		// Finalize statistics map
		statisticMap.finalize();
		// Print out the summary statistics
		data.summaryStatistics();

		// Create the caching data structure
		data.createCachingData();
		// Print out the summary statistics of the caching data structure
		data.cacheSummary();

		// Construct the nested case control sampler
		TwitterSampler estimator = new EdgeTwitterSampler(data, statisticMap);

		// Sample nested case-control data
		PrintWriter sampleOutput = new PrintWriter(new BufferedWriter(
				new FileWriter(new File(outputFile))));
		estimator.sampleCaseControlData(sampleOutput, controlSampleSize,
				sampleIndex);
		sampleOutput.close();

		return outputFile;

	}

	public static void runSAS(String caseControlFilePath,
			String outputDirectory, int sampleIndex, int eventType)
			throws Exception {

		String outSubDir;
		if (eventType == -1)
			outSubDir = "neg";
		else
			outSubDir = "pos";
		if (!(new File(outputDirectory + "/" + outSubDir)).exists()) {
			(new File(outputDirectory + "/" + outSubDir)).mkdir();
		}

		String sasFilePath = outputDirectory + "/" + outSubDir + "/samples_"
				+ sampleIndex + ".sas";
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(
				new File(sasFilePath))));

		String dataObject = "samples_" + sampleIndex;
		writer.write("data " + dataObject + "; \n");
		writer.write("infile '" + caseControlFilePath
				+ "' firstobs=1 delimiter='09'x LRECL=1000;" + "\n");
		writer.write("input Idx Time Node Censoring UsrTwt UsrNegTwt UsrFols "
				+ " PPosTwt PFols PFrds PRec PShrdFols PShrFrds PNumFrds "
				+ " NNegTwt NFols NFrds NRec NShrdFols NShrFrds NNumFrds "
				+ "  AllTwt  Fols  Frds  Rec  ShrFols   ShrFrds  NumFrds; \n");
		writer.write("Outcome = 2 - Censoring;\n");
		writer.write("run;\n");

		writer.write("proc phreg data=" + dataObject + "; \n");
		writer.write("model Outcome*Censoring(0) = UsrTwt UsrNegTwt UsrFols "
				+ " PPosTwt PFols PFrds PRec PShrdFols PShrFrds PNumFrds "
				+ " NNegTwt NFols NFrds NRec NShrdFols NShrFrds NNumFrds "
				+ "  AllTwt  Fols  Frds  Rec  ShrFols   ShrFrds  NumFrds; \n");
		writer.write("strata Idx;\n");
		writer.write("run;\n");

		writer.close();

		// -MEMSIZE 10G
		String sasOutputPath = (outputDirectory + "/" + outSubDir).trim();
		Process ps = Runtime.getRuntime().exec(
				"sas -MEMSIZE 10G " + sasFilePath + " -log '"
						+ sasOutputPath.trim() + "' -print '"
						+ sasOutputPath.trim() + "'");
		System.out.println("Waiting for SAS script to finish!!!");
		ps.waitFor();

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		int eventType = Integer.parseInt(args[0]); // 1 or -1

		String outputDirectory = args[1]; // output OR /gpfs/scratch/dqv100

		int sampleIndex = Integer.parseInt(args[2]); // 1
		double controlSampleSize = Double.parseDouble(args[3]); // 3200

		String allTweetsFilePath = args[4]; // data/allEvents.txt
		String nodeTimesFilePath = args[5]; // data/nodes.txt
		String edgeTimesFilePath = args[6]; // data/edges.txt

		double startingObservationTime = Double.parseDouble(args[7]); // 14583.43
		double endingObservationTime = Double.parseDouble(args[8]); // 14628.43

		System.out.println("Reading the file of all tweets...");

		allTweets = new ArrayList<Tweet>();
		readAllEventFile(allTweetsFilePath, allTweets);

		System.out.println("Getting Noise Relevant File");

		String eventTimesFilePath = getNoiseRelevantFile(allTweets,
				outputDirectory, sampleIndex, eventType);

		System.out.println("Getting Case Control Sampling File");

		String caseControlFilePath = getCaseControlSamplingFile(
				nodeTimesFilePath, edgeTimesFilePath, eventTimesFilePath,
				eventType, startingObservationTime, endingObservationTime,
				outputDirectory, controlSampleSize, sampleIndex);

		System.out.println("Running SAS script");

		runSAS(caseControlFilePath, outputDirectory, sampleIndex, eventType);

		System.out.println("DONE");
	}
}
