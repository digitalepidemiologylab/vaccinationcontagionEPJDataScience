package exp.twitter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class TwitterMisclassificationQSubGenerator {

	public static void main(String[] args) throws Exception {

		System.out.println("Running TwitterMisclassificationQSubGenerator");

		int eventType = Integer.parseInt(args[0]); // 1 OR -1

		String outputDirectory = args[1]; // output

		String outSubDir;
		if (eventType == -1)
			outSubDir = "neg";
		else
			outSubDir = "pos";
		if (!(new File(outputDirectory + "/" + outSubDir)).exists()) {
			(new File(outputDirectory + "/" + outSubDir)).mkdir();
		}

		int numRuns = Integer.parseInt(args[2]); // 200
		
		int controlSampleSize = Integer.parseInt(args[3]); // 3200
		
		String allTweetsFilePath = args[4]; // data/allEvents.txt
		String nodeTimesFilePath = args[5]; // data/nodes.txt
		String edgeTimesFilePath = args[6]; // data/edges.txt

		double startingObservationTime = Double.parseDouble(args[7]); // 14583.43
		double endingObservationTime = Double.parseDouble(args[8]); // 14628.43

		BufferedWriter commandFileWriter = new BufferedWriter(new FileWriter(
				new File(outputDirectory + "/" + outSubDir + "/qsubFile.cmd")));
		commandFileWriter.write("#!/bin/bash\n");


		for (int run = 1; run <= numRuns; run++) {

			File runFile = new File(outputDirectory + "/" + outSubDir
					+ "/run_" + run + ".txt");

			BufferedWriter runFileWriter = new BufferedWriter(new FileWriter(
					runFile));
			runFileWriter.write("#PBS -l nodes=1:ppn=1\n");
			runFileWriter.write("#PBS -l walltime=24:00:00\n");
			runFileWriter
					.write("echo \"Job started on `hostname` at `date`\"\n");
			runFileWriter.write("module load sas\n");
			runFileWriter.write("cd /gpfs/work/dqv100/twitter\n");
			runFileWriter
					.write("java -Xmx10g -classpath twitter.jar:lib/commons-collections-3.2.1.jar"
							+ " "
							+ "exp/twitter/TwitterMisclassificationExperiment"
							+ " "
							+ eventType
							+ " "
							+ outputDirectory
							+ " "
							+ run
							+ " "
							+ controlSampleSize
							+ " "
							+ allTweetsFilePath
							+ " "
							+ nodeTimesFilePath
							+ " "
							+ edgeTimesFilePath
							+ " "
							+ startingObservationTime
							+ " "
							+ endingObservationTime + "\n");
			runFileWriter.write("echo \"Job Ended at `date`\"\n");
			runFileWriter.close();

			commandFileWriter.write("qsub " + runFile.getAbsolutePath() + "\n");
		}

		commandFileWriter.write("\n");
		commandFileWriter.close();

	}
}
