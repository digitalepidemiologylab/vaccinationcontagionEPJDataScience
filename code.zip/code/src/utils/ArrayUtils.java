package utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;

public class ArrayUtils {

	public static double[] moveToDirection(double[] beta, double stepLength,
			double[] u) {
		double[] values = new double[beta.length];
		for (int k = 0; k < beta.length; k++)
			values[k] = beta[k] + stepLength * u[k];
		return values;
	}

	public static void reflexDoubleMatrix(double[][] matrix) {
		for (int h = 0; h < matrix.length; h++)
			for (int g = 0; g < h; g++) {
				matrix[g][h] = matrix[h][g];
			}
	}

	public static void resetDoubleArray(double[] array) {
		for (int k = 0; k < array.length; k++)
			array[k] = 0.0;
	}

	public static void resetDoubleMatrix(double[][] array) {
		for (int i = 0; i < array.length; i++)
			for (int j = 0; j < array[0].length; j++)
				array[i][j] = 0;
	}

	public static void copyDoubleMatrix(double[][] cloner, double[][] clonee) {
		if (cloner != null && clonee != null)
			for (int i = 0; i < cloner.length; i++)
				for (int j = 0; j < cloner[0].length; j++)
					clonee[i][j] = cloner[i][j];
	}

	public static void copyBooleanArray(boolean[] cloner, boolean[] clonee) {
		if (cloner != null && clonee != null)
			for (int i = 0; i < cloner.length; i++)
				clonee[i] = cloner[i];
	}

	public static void copyIntegerArray(int[] cloner, int[] clonee) {
		if (cloner != null && clonee != null)
			for (int i = 0; i < cloner.length; i++)
				clonee[i] = cloner[i];
	}

	public static void copyDoubleArray(double[] cloner, double[] clonee) {
		if (cloner != null && clonee != null)
			for (int i = 0; i < cloner.length; i++)
				clonee[i] = cloner[i];
	}

	public static void copyIntegerArrayList(ArrayList<Integer> cloner,
			ArrayList<Integer> clonee) {
		if (cloner != null && clonee != null)
			for (int i = 0; i < cloner.size(); i++)
				clonee.add(new Integer(cloner.get(i)));
	}

	public static void addNodalUpdatedNode(
			HashMap<Integer, TreeSet<Integer>> nodalUpdatedNodes, int nodeID,
			int statIndex) {
		if (nodalUpdatedNodes.containsKey(nodeID)) {
			nodalUpdatedNodes.get(nodeID).add(statIndex);
		} else {
			TreeSet<Integer> statSet = new TreeSet<Integer>();
			statSet.add(statIndex);
			nodalUpdatedNodes.put(nodeID, statSet);
		}
	}

}
