package data;

public class Tweet implements Comparable<Tweet> {

	public double time;
	public Integer userID;
	public short attitude;
	public String country;
	public String state;
	
	public Tweet(double _time, int _userID, short _attitude) {
		time = _time;
		userID = _userID;
		attitude = _attitude;
	}

	public Tweet(double _time, int _userID, short _attitude, String _country,
			String _state) {
		time = _time;
		userID = _userID;
		attitude = _attitude;
		country = _country;
		state = _state;
	}

	public int compareTo(Tweet e) {
		if (time < e.time)
			return -1;
		else if (time > e.time)
			return 1;
		else
			return 0;
	}
}
