package data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import component.event.ActionEvent;
import component.graph.EdgeEvent;

public class TwitterDataReader extends DataReader {

	@Override
	public int readNodeTimes(String nodeTimesFilePath,
			ArrayList<Double> nodeTimes) {
		int numOfNodes = 0;
		try {
			System.out.println("Reading the file of node arrival times!!!");
			BufferedReader nodeTimesReader = new BufferedReader(new FileReader(
					new File(nodeTimesFilePath)));

			// read the number of nodes
			String line = nodeTimesReader.readLine();
			if (line == null) {
				System.out.println("Errors in reading node arrival times: "
						+ nodeTimesFilePath);
				System.out.println("There is no number of nodes!!!");
				System.exit(-1);
			}
			numOfNodes = Integer.parseInt(line.trim());
			nodeTimes.ensureCapacity(numOfNodes);

			// read nodes and times
			int lineCounters = 0;
			while ((line = nodeTimesReader.readLine()) != null) {
				StringTokenizer myTokenizer = new StringTokenizer(line, "\t");
				double myTime = Double.parseDouble(myTokenizer.nextToken()
						.trim());
				int myNumNodes = Integer.parseInt(myTokenizer.nextToken()
						.trim());
				for (int i = 0; i < myNumNodes; i++) {
					lineCounters++;
					if (lineCounters % 1000000 == 0)
						System.out.println("Reading up to " + lineCounters);
					int nodeID = Integer.parseInt(nodeTimesReader.readLine()
							.trim());
					nodeTimes.add(nodeID, myTime);
				}
			}
			nodeTimesReader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Errors in reading node arrival times: "
					+ nodeTimesFilePath);
		}

		return numOfNodes;
	}

	@Override
	public int readEdgeTimes(String edgeTimesFilePath,
			ArrayList<EdgeEvent> edgeTimes) {
		int numOfEdges = 0;
		String line = null;
		try {
			System.out.println("Reading the file of edge arrival times!!!");
			BufferedReader edgeTimesReader = new BufferedReader(new FileReader(
					new File(edgeTimesFilePath)));

			// read the number of edges
			line = edgeTimesReader.readLine();
			if (line == null) {
				System.out.println("Errors in reading edge arrival times: "
						+ edgeTimesFilePath);
				System.out.println("There is no number of edges!!!");
				System.exit(-1);
			}
			numOfEdges = Integer.parseInt(line.trim());
			edgeTimes.ensureCapacity(numOfEdges);

			// read edges and times
			model.initializeEdge2RowMap(numOfEdges);
			int currentRow = 0;
			int lineCounters = 0;
			while ((line = edgeTimesReader.readLine()) != null) {
				StringTokenizer myTokenizer = new StringTokenizer(line, "\t");
				//System.out.println("At line: " + line);
				double myTime = Double.parseDouble(myTokenizer.nextToken()
						.trim());
				//System.out.println("myTime: " + myTime);
				int myNumEdges = Integer.parseInt(myTokenizer.nextToken()
						.trim());
				//System.out.println("myNumEdges: " + myNumEdges);
				for (int i = 0; i < myNumEdges; i++) {
					lineCounters++;
					if (lineCounters % 1000000 == 0)
						System.out.println("Reading up to " + lineCounters);
					line = edgeTimesReader.readLine().trim();
					//System.out.println("At line: " + line);
					StringTokenizer tokenizer = new StringTokenizer(line, "\t");
					int senderID = Integer.parseInt(tokenizer.nextToken());
					int receiverID = Integer.parseInt(tokenizer.nextToken());
					edgeTimes.add(new EdgeEvent(senderID, receiverID, myTime));
					model.updateEdge2RowMap(senderID, receiverID, currentRow++);
				}
			}
			edgeTimesReader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Errors in reading edge arrival times: "
					+ edgeTimesFilePath);
			System.out.println("At line: " + line);
		}
		return numOfEdges;
	}

	@Override
	public int readEventTimes(String eventTimesFilePath,
			ArrayList<ActionEvent> eventTimes,
			ArrayList<ActionEvent> interestEventTimes) {
		int numOfEvents = 0;
		try {
			System.out.println("Reading the file of event arrival times!!!");
			BufferedReader eventTimesReader = new BufferedReader(
					new FileReader(new File(eventTimesFilePath)));

			// read the number of events
			String line = eventTimesReader.readLine();
			if (line == null) {
				System.out.println("Errors in reading event  times: "
						+ eventTimesFilePath);
				System.out.println("There is no number of events!!!");
				System.exit(-1);
			}
			numOfEvents = Integer.parseInt(line.trim());
			eventTimes.ensureCapacity(numOfEvents);

			// read events
			int lineCounters = 0;
			ArrayList<Integer> interestEventIndices = new ArrayList<Integer>();
			while ((line = eventTimesReader.readLine()) != null) {
				lineCounters++;
				if (lineCounters % 1000000 == 0)
					System.out.println("Reading up to " + lineCounters);
				StringTokenizer myTokenizer = new StringTokenizer(line, "\t");
				double eventTime = Double.parseDouble(myTokenizer.nextToken()
						.trim());
				int eventNode = Integer
						.parseInt(myTokenizer.nextToken().trim());
				int eventType = Integer
						.parseInt(myTokenizer.nextToken().trim());
				ActionEvent event = new ActionEvent(eventNode, eventType,
						eventTime);
				eventTimes.add(event);

				if (eventType == model.interestEventType
						&& model.startingObservationTime <= eventTime
						&& eventTime <= model.endingObservationTime) {
					// add new interest event
					interestEventTimes.add(event);
					interestEventIndices.add(eventTimes.size() - 1);
				}
			}

			// Resolve tied events
			// break tied event times
			for (int i = 0; i < interestEventTimes.size(); i++) {
				ActionEvent markingEvent = interestEventTimes.get(i);
				for (int j = i + 1; j < interestEventTimes.size(); j++) {
					ActionEvent futureMarkingEvent = interestEventTimes.get(j);
					if (futureMarkingEvent.timeStamp == markingEvent.timeStamp)
						for (int k = interestEventIndices.get(j); k > interestEventIndices
								.get(j - 1); k--)
							eventTimes.get(k).timeStamp += (j - i) * 1e-10;
				}
			}
			eventTimesReader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Errors in reading eventl times: "
					+ eventTimesFilePath);
		}

		return numOfEvents;
	}
}
