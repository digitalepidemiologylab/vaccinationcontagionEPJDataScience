package data;

import java.util.ArrayList;

import model.SingleTypedNetworkEventModel;

import component.event.ActionEvent;
import component.graph.EdgeEvent;

public abstract class DataReader {

	SingleTypedNetworkEventModel model;

	public void setNetworkEventModel(SingleTypedNetworkEventModel _model) {
		model = _model;
	}

	public abstract int readNodeTimes(String nodeTimesFilePath,
			ArrayList<Double> nodeTimes);

	public abstract int readEdgeTimes(String edgeTimesFilePath,
			ArrayList<EdgeEvent> edgeTimes);

	public abstract int readEventTimes(String eventTimesFilePath,
			ArrayList<ActionEvent> eventTimes,
			ArrayList<ActionEvent> interestEventTimes);
}
