package component.cache;

public class UpdateElement {
	public int statIndex;
	public double statValue;
	
	public UpdateElement(int _index, double _value) {
		statIndex = _index;
		statValue = _value;
	}
}
