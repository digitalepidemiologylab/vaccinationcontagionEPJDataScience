package component.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class MatrixUpdateCache {
	protected ArrayList<HashMap<Integer, ArrayList<UpdateElement>>> container;

	public MatrixUpdateCache(int size) {
		container = new ArrayList<HashMap<Integer, ArrayList<UpdateElement>>>(
				size);
		for (int i = 0; i < size; i++)
			container.add(i, null);
	}

	public void cacheElementUpdate(int index, double[][] matrix, int row, int col) {
		UpdateElement updateElement = new UpdateElement(col, matrix[row][col]);
		if (container.get(index).containsKey(row)) {
			container.get(index).get(row).add(updateElement);
		} else {
			ArrayList<UpdateElement> updateList = new ArrayList<UpdateElement>();
			updateList.add(updateElement);
			container.get(index).put(row, updateList);
		}
	}

	public void cacheMatrixUpdates(int index, double[][] matrix,
			HashMap<Integer, TreeSet<Integer>> updatedRows) {
		HashMap<Integer, ArrayList<UpdateElement>> currentCache = new HashMap<Integer, ArrayList<UpdateElement>>();
		Set<Map.Entry<Integer, TreeSet<Integer>>> updatedEntries = updatedRows
				.entrySet();
		for (Map.Entry<Integer, TreeSet<Integer>> entry : updatedEntries) {
			int updatedRow = entry.getKey();
			for (Iterator<Integer> it = entry.getValue().iterator(); it
					.hasNext();) {
				int statIndex = it.next();
				double statValue = matrix[updatedRow][statIndex];
				if (currentCache.containsKey(updatedRow)) {
					currentCache.get(updatedRow).add(
							new UpdateElement(statIndex, statValue));
				} else {
					ArrayList<UpdateElement> elements = new ArrayList<UpdateElement>();
					elements.add(new UpdateElement(statIndex, statValue));
					currentCache.put(updatedRow, elements);
				}
			}
		}
		container.set(index, currentCache);

	}

	public void updateMatrix(int index, double[][] matrix) {
		Set<Map.Entry<Integer, ArrayList<UpdateElement>>> allUpdates = container
				.get(index).entrySet();
		for (Map.Entry<Integer, ArrayList<UpdateElement>> myUpdates : allUpdates) {
			int updatedRow = myUpdates.getKey();
			for (Iterator<UpdateElement> it = myUpdates.getValue()
					.listIterator(); it.hasNext();) {
				UpdateElement element = it.next();
				matrix[updatedRow][element.statIndex] = element.statValue;
			}
		}
	}
}
