package component.event;

public class NodeEvent implements Comparable<NodeEvent> {

	public int nodeID;
	public double timeStamp;

	public NodeEvent(int _id, double _time) {
		nodeID = _id;
		timeStamp = _time;
	}

	public int compareTo(NodeEvent e) {
		if (timeStamp < e.timeStamp)
			return -1;
		else if (timeStamp > e.timeStamp)
			return 1;
		else
			return 0;
	}

}
