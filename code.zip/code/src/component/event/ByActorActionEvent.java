package component.event;

public class ByActorActionEvent implements Comparable<ByActorActionEvent> {

	public int type;
	public double timeStamp;

	public ByActorActionEvent(int _eventType, double _eventTime) {
		type = _eventType;
		timeStamp = _eventTime;
	}

	public int compareTo(ByActorActionEvent e) {
		if (timeStamp < e.timeStamp)
			return -1;
		else if (timeStamp > e.timeStamp)
			return 1;
		else
			return 0;
	}
}
