package component.event;

import java.util.ArrayList;
import java.util.Iterator;

public class EventUtils {

	public static void deepCopyNodeEvents(
			ArrayList<ArrayList<ByActorActionEvent>> cloner,
			ArrayList<ArrayList<ByActorActionEvent>> clonee) {
		for (int i = 0; i < cloner.size(); i++) {
			if (cloner.get(i) != null) {
				ArrayList<ByActorActionEvent> eventList = new ArrayList<ByActorActionEvent>(
						cloner.get(i).size());
				for (Iterator<ByActorActionEvent> it = cloner.get(i).iterator(); it
						.hasNext();) {
					ByActorActionEvent eventTime = it.next();
					eventList.add(eventTime);
				}
				clonee.add(i, eventList);
			} else
				clonee.add(i, null);
		}
	}

}
