package component.event;

public class EdgeEvent implements Comparable<EdgeEvent> {

	public int senderID;
	public int receiverID;
	public double timeStamp;

	public EdgeEvent(int _sender, int _receiver, double _time) {
		senderID = _sender;
		receiverID = _receiver;
		timeStamp = _time;
	}

	public int compareTo(EdgeEvent e) {
		if (timeStamp < e.timeStamp)
			return -1;
		else if (timeStamp > e.timeStamp)
			return 1;
		else
			return 0;
	}
}
