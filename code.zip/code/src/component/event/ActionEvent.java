package component.event;

public class ActionEvent implements Comparable<ActionEvent> {

	public int nodeID;
	public int type;
	public double timeStamp;

	public ActionEvent(int _id, int _type, double _time) {
		nodeID = _id;
		type = _type;
		timeStamp = _time;
	}

	public int compareTo(ActionEvent e) {
		if (timeStamp < e.timeStamp)
			return -1;
		else if (timeStamp > e.timeStamp)
			return 1;
		else
			return 0;
	}
}
