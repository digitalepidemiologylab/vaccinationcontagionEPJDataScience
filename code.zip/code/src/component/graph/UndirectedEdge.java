package component.graph;

public class UndirectedEdge implements Comparable<UndirectedEdge> {

	public int senderID;
	public int receiverID;

	public UndirectedEdge(int _sender, int _receiver) {
		senderID = _sender;
		receiverID = _receiver;
	}

	public int compareTo(UndirectedEdge edge) {
		if ((senderID == edge.senderID && receiverID == edge.receiverID)
				|| (senderID == edge.receiverID && receiverID == edge.senderID))
			return 0;
		else if (senderID > edge.senderID)
			return 1;
		else if (senderID < edge.senderID)
			return -1;
		else if (receiverID >= edge.receiverID)
			return 1;
		else
			return -1;
	}

	public boolean equals(Object obj) {
		UndirectedEdge edge = (UndirectedEdge) obj;
		if ((senderID == edge.senderID && receiverID == edge.receiverID)
				|| (senderID == edge.receiverID && receiverID == edge.senderID))
			return true;
		else
			return false;
	}

	public int hashCode() {
		return (new Integer(senderID + receiverID)).hashCode();
	}

}
