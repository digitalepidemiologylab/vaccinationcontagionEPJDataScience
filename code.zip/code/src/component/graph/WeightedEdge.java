package component.graph;

public class WeightedEdge implements Comparable<WeightedEdge> {
	public int senderID;
	public int receiverID;
	public double weight;

	public WeightedEdge(int _sender, int _receiver, double _weight) {
		senderID = _sender;
		receiverID = _receiver;
		weight = _weight;
	}

	public int compareTo(WeightedEdge edge) {
		if (senderID == edge.senderID && receiverID == edge.receiverID
				&& weight == edge.weight)
			return 0;
		else if (senderID > edge.senderID)
			return 1;
		else if (senderID < edge.senderID)
			return -1;
		else {
			if (receiverID > edge.receiverID)
				return 1;
			else if (receiverID < edge.receiverID)
				return -1;
			else {
				if (weight >= edge.weight)
					return 1;
				else
					return -1;
			}
		}
	}

	public boolean equals(Object obj) {
		WeightedEdge edge = (WeightedEdge) obj;
		if (senderID == edge.senderID & receiverID == edge.receiverID
				& weight == edge.weight)
			return true;
		else
			return false;
	}

	public int hashCode() {
		return (new Integer(senderID)).hashCode()
				+ (new Integer(receiverID)).hashCode()
				+ (new Double(weight)).hashCode();
	}

}
