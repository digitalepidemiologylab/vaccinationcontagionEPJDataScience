package component.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class GraphUtils {

	public static void deepCopyEdges(ArrayList<TreeSet<EndNode>> cloner,
			ArrayList<TreeSet<EndNode>> clonee) {
		for (int i = 0; i < cloner.size(); i++) {
			if (cloner.get(i) != null) {
				TreeSet<EndNode> nodeSet = new TreeSet<EndNode>();
				for (Iterator<EndNode> it = cloner.get(i).iterator(); it
						.hasNext();) {
					EndNode endNode = it.next();
					nodeSet.add(endNode);
				}
				clonee.add(i, nodeSet);
			} else
				clonee.add(i, null);
		}
	}

}
