package component.graph;

public class EdgeEvent implements Comparable<EdgeEvent> {

	public int senderID;
	public int receiverID;
	public double timeStamp;

	public EdgeEvent(int _sender, int _receiver, double _time) {
		senderID = _sender;
		receiverID = _receiver;
		timeStamp = _time;
	}

	public int compareTo(EdgeEvent e) {
		if (senderID == e.senderID && receiverID == e.receiverID
				&& timeStamp == e.timeStamp)
			return 0;
		else
			return 1;
	}
	
	public int hashCode() {
		return (new Integer(senderID)).hashCode()
				+ (new Integer(receiverID)).hashCode();
	}
}
