package component.graph;

public class Edge implements Comparable<Edge> {
	public int senderID;
	public int receiverID;

	public Edge(int _sender, int _receiver) {
		senderID = _sender;
		receiverID = _receiver;
	}

	public int compareTo(Edge edge) {
		if (senderID == edge.senderID && receiverID == edge.receiverID)
			return 0;
		else if (senderID > edge.senderID)
			return 1;
		else if (senderID < edge.senderID)
			return -1;
		else if (receiverID >= edge.receiverID)
			return 1;
		else
			return -1;
	}

	public boolean equals(Object obj) {
		Edge edge = (Edge) obj;
		if (senderID == edge.senderID && receiverID == edge.receiverID)
			return true;
		else
			return false;
	}

	public int hashCode() {
		return (new Integer(senderID)).hashCode()
				+ (new Integer(receiverID)).hashCode();
	}
}
