package component.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class EdgeListGraph {

	public int numOfNodes;

	// Each element i of this list contains out-edges from node i
	// (i.e. senderID = i). EndNode contains receiverID and the corresponding
	// edgeID which will be used to access the edge influential covariates
	public ArrayList<TreeSet<EndNode>> outEdges;

	// Each element i of this list contains in-edges to node i
	// (i.e. receiverID = i). EndNode contains senderID and the corresponding
	// edgeID which will be used to access edge influential covariates
	public ArrayList<TreeSet<EndNode>> inEdges;

	public EdgeListGraph(EdgeListGraph graph) {

		numOfNodes = graph.numOfNodes;

		outEdges = new ArrayList<TreeSet<EndNode>>(graph.outEdges.size());
		GraphUtils.deepCopyEdges(graph.outEdges, outEdges);

		inEdges = new ArrayList<TreeSet<EndNode>>(graph.inEdges.size());
		GraphUtils.deepCopyEdges(graph.inEdges, inEdges);
	}

	public EdgeListGraph(int _numOfNodes) {
		numOfNodes = _numOfNodes;
		outEdges = new ArrayList<TreeSet<EndNode>>(numOfNodes);
		inEdges = new ArrayList<TreeSet<EndNode>>(numOfNodes);
		for (int i = 0; i < numOfNodes; i++) {
			outEdges.add(i, null);
			inEdges.add(i, null);
		}
	}

	public void addEdge(DirectedEdge edge) {
		int senderID = edge.senderID;
		int receiverID = edge.receiverID;

		// currentOutEdges
		if (outEdges.get(senderID) != null) {
			outEdges.get(senderID).add(new EndNode(receiverID, edge.edgeID));
		} else {
			TreeSet<EndNode> nodeSet = new TreeSet<EndNode>();
			nodeSet.add(new EndNode(receiverID, edge.edgeID));
			outEdges.set(senderID, nodeSet);
		}

		// currentInEdges
		if (inEdges.get(receiverID) != null) {
			inEdges.get(receiverID).add(new EndNode(senderID, edge.edgeID));
		} else {
			TreeSet<EndNode> nodeSet = new TreeSet<EndNode>();
			nodeSet.add(new EndNode(senderID, edge.edgeID));
			inEdges.set(receiverID, nodeSet);
		}
	}

	public boolean edgeExist(int senderID, int receiverID) {
		TreeSet<EndNode> set = outEdges.get(senderID);
		if (set != null)
			for (Iterator<EndNode> it = set.iterator(); it.hasNext();) {
				EndNode endNode = it.next();
				if (receiverID == endNode.nodeID)
					return true;
			}
		return false;
	}

	public long getOutDegree(int nodeID) {
		TreeSet<EndNode> set = outEdges.get(nodeID);
		if (set != null)
			return set.size();
		else
			return 0;
	}

	public long getInDegree(int nodeID) {
		TreeSet<EndNode> set = inEdges.get(nodeID);
		if (set != null)
			return set.size();
		else
			return 0;
	}

	public ArrayList<Integer> getFriends(int nodeID) {
		ArrayList<Integer> friends = new ArrayList<Integer>();
		TreeSet<EndNode> set = outEdges.get(nodeID);
		if (set != null)
			for (Iterator<EndNode> it = set.iterator(); it.hasNext();) {
				EndNode endNode = it.next();
				friends.add(endNode.nodeID);
			}
		return friends;
	}

	public ArrayList<Integer> getFollowers(int nodeID) {
		ArrayList<Integer> fans = new ArrayList<Integer>();
		TreeSet<EndNode> set = inEdges.get(nodeID);
		if (set != null)
			for (Iterator<EndNode> it = set.iterator(); it.hasNext();) {
				EndNode endNode = it.next();
				fans.add(endNode.nodeID);
			}
		return fans;
	}

}
