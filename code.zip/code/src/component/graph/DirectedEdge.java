package component.graph;

public class DirectedEdge implements Comparable<DirectedEdge> {

	public int senderID;
	public int receiverID;
	public int edgeID;

	public DirectedEdge(int _sender, int _receiver, int _edgeID) {
		senderID = _sender;
		receiverID = _receiver;
		edgeID = _edgeID;
	}

	public int compareTo(DirectedEdge edge) {
		if (senderID == edge.senderID & receiverID == edge.receiverID)
			return 0;
		else if (senderID > edge.senderID)
			return 1;
		else if (senderID < edge.senderID)
			return -1;
		else if (receiverID >= edge.receiverID)
			return 1;
		else
			return -1;
	}
}
