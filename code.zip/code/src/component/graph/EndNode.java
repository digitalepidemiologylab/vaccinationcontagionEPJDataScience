package component.graph;

public class EndNode implements Comparable<EndNode> {
	public int nodeID;
	public int edgeID;

	public EndNode(int _nodeID, int _edgeID) {
		nodeID = _nodeID;
		edgeID = _edgeID;
	}

	public int compareTo(EndNode e) {
		if (nodeID < e.nodeID)
			return -1;
		else if (nodeID > e.nodeID)
			return 1;
		else
			return 0;
	}

	public boolean equals(Object obj) {
		EndNode endNode = (EndNode) obj;
		if (nodeID == endNode.nodeID)
			return true;
		else
			return false;
	}

	public int hashCode() {
		return (new Integer(nodeID)).hashCode();
	}
}
