package estimator;

public class TimeCumulativeCoefficients {
	public double timeStamp;
	public double[] cumulativeCoefficients;

	public TimeCumulativeCoefficients(double _timeStamp, int _numOfCoefficients) {
		timeStamp = _timeStamp;
		cumulativeCoefficients = new double[_numOfCoefficients];
	}
}
