package estimator.sampler;

import java.util.Iterator;

import utils.ArrayUtils;

import component.graph.EndNode;

import estimator.TwitterStatisticMap;
import estimator.EstimatorException;

import model.Edge2RowException;
import model.SingleTypedNetworkEventModel;
import model.twitter.TwitterModel;

public class EdgeTwitterSampler extends TwitterSampler {

	protected TwitterStatisticMap statisticMap;

	public EdgeTwitterSampler(SingleTypedNetworkEventModel _data,
			TwitterStatisticMap _statisticMap) throws EstimatorException {
		
		super(_data);
		
		System.out.println("Constructing EdgeTwitterSampler");
		
		if (!(data instanceof TwitterModel))
			throw new EstimatorException(data.getClass().getName()
					+ " must be used with TwitterModel!!!");
		
		statisticMap = _statisticMap;
		
		initStatistics();
	}

	protected void initStatistics() {
		
		System.out.println("Init statistics in EdgeTwitterSampler");
		
		int numberOfSusceptibleStatistics = statisticMap.susceptibleStatistics.length;
		
		int numberOfPositiveStatistics = statisticMap.positiveNodeStatistics.length
				+ statisticMap.positiveEdgeStatistics.length + 1;
		
		int numberOfNegativeStatistics = statisticMap.negativeNodeStatistics.length
				+ statisticMap.negativeEdgeStatistics.length + 1;
		
		int numberOfFriendStatistics = statisticMap.friendNodeStatistics.length
				+ statisticMap.friendEdgeStatistics.length + 1;
		
		statistics = new double[numberOfSusceptibleStatistics
				+ numberOfPositiveStatistics + numberOfNegativeStatistics
				+ numberOfFriendStatistics];
		
	}

	@Override
	protected void computeStatistics(int nodeID, double[] statistics) {

		TwitterModel myData = (TwitterModel) data;

		// reset the array
		ArrayUtils.resetDoubleArray(statistics);

		// fill susceptible statistics
		for (int h = 0; h < statisticMap.susceptibleStatistics.length; h++) {
			double statValue = myData.currentNodeStatistics[nodeID][statisticMap.susceptibleStatistics[h]];
			if (statisticMap.susceptibleIsLog[h])
				statistics[h] = logTransform(statValue);
			else
				statistics[h] = statValue;
		}

		// bases of positive statistics
		int positiveNodeBase = statisticMap.susceptibleStatistics.length;
		int positiveEdgeBase = positiveNodeBase
				+ statisticMap.positiveNodeStatistics.length;
		int positiveFriends = positiveEdgeBase
				+ statisticMap.positiveEdgeStatistics.length;
		// bases of negative statistics
		int negativeNodeBase = positiveFriends + 1;
		int negativeEdgeBase = negativeNodeBase
				+ statisticMap.negativeNodeStatistics.length;
		int negativeFriends = negativeEdgeBase
				+ statisticMap.negativeEdgeStatistics.length;
		// bases of friend statistics
		int friendNodeBase = negativeFriends + 1;
		int friendEdgeBase = friendNodeBase
				+ statisticMap.friendNodeStatistics.length;
		int friendFriends = friendEdgeBase
				+ statisticMap.friendEdgeStatistics.length;

		// accumulate statistics by iterating through friends of nodeID
		if (myData.currentGraph.outEdges.get(nodeID) != null) {
			for (Iterator<EndNode> it = myData.currentGraph.outEdges
					.get(nodeID).iterator(); it.hasNext();) {
				EndNode friend = it.next();
				// compute and fill positively infectious statistics
				if (myData.currentIsPositivelyInfectious[friend.nodeID]) {
					// come the positive weight
					double posWeight = (double) myData.currentPositiveTweetCounts[friend.nodeID]
							/ myData.currentAllTweetCounts[friend.nodeID];
					// get node statistics
					for (int h = 0; h < statisticMap.positiveNodeStatistics.length; h++)
						statistics[positiveNodeBase + h] += posWeight
								* myData.currentNodeStatistics[friend.nodeID][statisticMap.positiveNodeStatistics[h]];
					// get edge statistics
					for (int h = 0; h < statisticMap.positiveEdgeStatistics.length; h++) {
						int rowIndex = -1;
						try {
							rowIndex = myData.getRowIndexOfEdge(nodeID,
									friend.nodeID);
							if (rowIndex >= 0)
								statistics[positiveEdgeBase + h] += posWeight
										* myData.currentEdgeStatistics[rowIndex][statisticMap.positiveEdgeStatistics[h]];
						} catch (Edge2RowException e) {
							e.printStackTrace();
							System.exit(-1);
						}
					}
					statistics[positiveFriends] += posWeight;
				}
				// compute and fill negatively infectious statistics
				if (myData.currentIsNegativelyInfectious[friend.nodeID]) {
					// come the negative weight
					double negWeight = (double) myData.currentNegativeTweetCounts[friend.nodeID]
							/ myData.currentAllTweetCounts[friend.nodeID];
					// get node statistics
					for (int h = 0; h < statisticMap.negativeNodeStatistics.length; h++)
						statistics[negativeNodeBase + h] += negWeight
								* myData.currentNodeStatistics[friend.nodeID][statisticMap.negativeNodeStatistics[h]];
					// get edge statistics
					for (int h = 0; h < statisticMap.negativeEdgeStatistics.length; h++) {
						int rowIndex = -1;
						try {
							rowIndex = myData.getRowIndexOfEdge(nodeID,
									friend.nodeID);
							if (rowIndex >= 0)
								statistics[negativeEdgeBase + h] += negWeight
										* myData.currentEdgeStatistics[rowIndex][statisticMap.negativeEdgeStatistics[h]];
						} catch (Edge2RowException e) {
							e.printStackTrace();
							System.exit(-1);
						}
					}
					statistics[negativeFriends] += negWeight;
				}
				// compute and fill friend statistics.
				// Here no condition needs to be checked
				// get node statistics
				for (int h = 0; h < statisticMap.friendNodeStatistics.length; h++)
					statistics[friendNodeBase + h] += myData.currentNodeStatistics[friend.nodeID][statisticMap.friendNodeStatistics[h]];
				// get edge statistics
				for (int h = 0; h < statisticMap.friendEdgeStatistics.length; h++) {
					int rowIndex = -1;
					try {
						rowIndex = myData.getRowIndexOfEdge(nodeID,
								friend.nodeID);
						if (rowIndex >= 0)
							statistics[friendEdgeBase + h] += myData.currentEdgeStatistics[rowIndex][statisticMap.friendEdgeStatistics[h]];
					} catch (Edge2RowException e) {
						e.printStackTrace();
						System.exit(-1);
					}
				}
				statistics[friendFriends] += 1.0;
			}
		}

		// normalize positive statistics
		if (statistics[positiveFriends] > 0) {
			// normalize node statistics
			for (int h = 0; h < statisticMap.positiveNodeStatistics.length; h++) {
				statistics[positiveNodeBase + h] /= statistics[positiveFriends];
				if (statisticMap.positiveNodeIsLog[h])
					statistics[positiveNodeBase + h] = logTransform(statistics[positiveNodeBase
							+ h]);
			}
			// normalize edge statistics
			for (int h = 0; h < statisticMap.positiveEdgeStatistics.length; h++) {
				statistics[positiveEdgeBase + h] /= statistics[positiveFriends];
				if (statisticMap.positiveEdgeIsLog[h])
					statistics[positiveEdgeBase + h] = logTransform(statistics[positiveEdgeBase
							+ h]);
			}
		}
		// normalize negative statistics
		if (statistics[negativeFriends] > 0) {
			// normalize node statistics
			for (int h = 0; h < statisticMap.negativeNodeStatistics.length; h++) {
				statistics[negativeNodeBase + h] /= statistics[negativeFriends];
				if (statisticMap.negativeNodeIsLog[h])
					statistics[negativeNodeBase + h] = logTransform(statistics[negativeNodeBase
							+ h]);
			}
			// normalize edge statistics
			for (int h = 0; h < statisticMap.negativeEdgeStatistics.length; h++) {
				statistics[negativeEdgeBase + h] /= statistics[negativeFriends];
				if (statisticMap.negativeEdgeIsLog[h])
					statistics[negativeEdgeBase + h] = logTransform(statistics[negativeEdgeBase
							+ h]);
			}
		}
		// normalize friend statistics
		if (statistics[friendFriends] > 0) {
			// normalize node statistics
			for (int h = 0; h < statisticMap.friendNodeStatistics.length; h++) {
				statistics[friendNodeBase + h] /= statistics[friendFriends];
				if (statisticMap.friendNodeIsLog[h])
					statistics[friendNodeBase + h] = logTransform(statistics[friendNodeBase
							+ h]);
			}
			// normalize edge statistics
			for (int h = 0; h < statisticMap.friendEdgeStatistics.length; h++) {
				statistics[friendEdgeBase + h] /= statistics[friendFriends];
				if (statisticMap.friendEdgeIsLog[h])
					statistics[friendEdgeBase + h] = logTransform(statistics[friendEdgeBase
							+ h]);
			}
		}

	}

}
