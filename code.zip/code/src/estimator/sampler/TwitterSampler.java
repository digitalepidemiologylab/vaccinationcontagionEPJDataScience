package estimator.sampler;

import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Random;

import java.util.TreeSet;


import model.NestedCaseControlSampler;
import model.SingleTypedNetworkEventModel;

public abstract class TwitterSampler implements NestedCaseControlSampler {

	public static final int EVENT = 1;
	public static final int CENSORING = 0;

	protected SingleTypedNetworkEventModel data;

	protected double[] statistics;

	protected static DecimalFormat outputDecimalTimeFormatter = new DecimalFormat(
			".0000000000");

	public TwitterSampler(SingleTypedNetworkEventModel _data) {
		System.out.println("Constructing TwitterSampler");
		data = _data;
	}

	public int getNumberOfStatistics() {
		return statistics.length;
	}

	protected abstract void computeStatistics(int nodeID, double[] statistics);

	protected double logTransform(double value) {
		return Math.log(value + .5);
	}

	// print statistics of a row into a file
	public void outputStatistics2File(PrintWriter outputWriter, int index,
			double eventTime, int rowIndex, boolean isEvent) {
		// print time, node, eventFlag
		outputWriter.write(index + "\t");
		outputWriter.write(outputDecimalTimeFormatter.format(eventTime) + "\t");
		outputWriter.write(rowIndex + "\t");
		if (isEvent)
			outputWriter.write(1 + "\t");
		else
			outputWriter.write(0 + "\t");
		// get statistics of event node
		computeStatistics(rowIndex, statistics);
		// print statistics to the file
		for (int k = 0; k < statistics.length; k++)
			outputWriter.write(statistics[k] + "\t");
		outputWriter.write("\n");
	}

	// get nested case-control samples, i.e for each event we record
	// statistics of the event node as well as statistics of sampleRatio
	// non-event nodes which are at-risk at that time
	public void sampleCaseControlData(PrintWriter outputWriter,
			double controlSampleSize, long seed) {

		Random sampler = new Random(seed);

		// start rolling edges
		data.startEventRolling();

		for (int index = 0; index < data.numOfInterestEvents; index++) {

			if (index % 100 == 0)
				System.out.println("Sampling up to event " + index);

			int eventNode = data.getCurrentEvent().nodeID;
			double eventTime = data.getCurrentEvent().timeStamp;
			// write statistics of the event node
			outputStatistics2File(outputWriter, index, eventTime, eventNode,
					true);
			// sample non-event nodes and write their statistics to file
			TreeSet<Integer> selectedNodes = new TreeSet<Integer>();
			for (int i = 0; i < controlSampleSize; i++) {
				int selectedNode;
				do {
					// select a node randomly
					selectedNode = sampler.nextInt(data.numOfNodes);
				} while (!(selectedNode != eventNode
						&& !selectedNodes.contains(selectedNode) && data.currentIsAtRisk[selectedNode]));
				// one non-event node found, select it and print its statistics
				// to file
				selectedNodes.add(selectedNode);
				outputStatistics2File(outputWriter, index, eventTime,
						selectedNode, false);
			}

			// roll to the next event
			data.rollToNextEvent();
		}

		// finish rolling edges
		data.endEventRolling();
	}

}
