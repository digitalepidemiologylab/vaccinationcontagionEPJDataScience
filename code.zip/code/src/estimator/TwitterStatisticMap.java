package estimator;

import java.util.ArrayList;

import stat.twitter.edge.SignedEdgeStatistic;
import stat.twitter.node.SignedNodeStatistic;

public class TwitterStatisticMap {

	public int[] susceptibleStatistics;
	public int[] positiveNodeStatistics;
	public int[] positiveEdgeStatistics;
	public int[] negativeNodeStatistics;
	public int[] negativeEdgeStatistics;
	public int[] friendNodeStatistics;
	public int[] friendEdgeStatistics;

	public boolean[] susceptibleIsLog;
	public boolean[] positiveNodeIsLog;
	public boolean[] positiveEdgeIsLog;
	public boolean[] negativeNodeIsLog;
	public boolean[] negativeEdgeIsLog;
	public boolean[] friendNodeIsLog;
	public boolean[] friendEdgeIsLog;

	protected ArrayList<Integer> _susceptibleStatistics;
	protected ArrayList<Integer> _positiveNodeStatistics;
	protected ArrayList<Integer> _positiveEdgeStatistics;
	protected ArrayList<Integer> _negativeNodeStatistics;
	protected ArrayList<Integer> _negativeEdgeStatistics;
	protected ArrayList<Integer> _friendNodeStatistics;
	protected ArrayList<Integer> _friendEdgeStatistics;

	protected ArrayList<Boolean> _susceptibleIsLog;
	protected ArrayList<Boolean> _positiveNodeIsLog;
	protected ArrayList<Boolean> _positiveEdgeIsLog;
	protected ArrayList<Boolean> _negativeNodeIsLog;
	protected ArrayList<Boolean> _negativeEdgeIsLog;
	protected ArrayList<Boolean> _friendNodeIsLog;
	protected ArrayList<Boolean> _friendEdgeIsLog;

	public TwitterStatisticMap() {
		_susceptibleStatistics = new ArrayList<Integer>();
		_susceptibleIsLog = new ArrayList<Boolean>();

		_positiveNodeStatistics = new ArrayList<Integer>();
		_positiveNodeIsLog = new ArrayList<Boolean>();

		_positiveEdgeStatistics = new ArrayList<Integer>();
		_positiveEdgeIsLog = new ArrayList<Boolean>();

		_negativeNodeStatistics = new ArrayList<Integer>();
		_negativeNodeIsLog = new ArrayList<Boolean>();

		_negativeEdgeStatistics = new ArrayList<Integer>();
		_negativeEdgeIsLog = new ArrayList<Boolean>();

		_friendNodeStatistics = new ArrayList<Integer>();
		_friendNodeIsLog = new ArrayList<Boolean>();

		_friendEdgeStatistics = new ArrayList<Integer>();
		_friendEdgeIsLog = new ArrayList<Boolean>();
	}

	public void addSusceptibleStatistics(SignedNodeStatistic nodeStatistic) {
		_susceptibleStatistics.add(nodeStatistic.getStatIndex());
		_susceptibleIsLog.add(false);
	}

	public void addSusceptibleStatistics(SignedNodeStatistic nodeStatistic,
			boolean isLog) {
		_susceptibleStatistics.add(nodeStatistic.getStatIndex());
		_susceptibleIsLog.add(isLog);
	}

	public void addPositiveNodeStatistics(SignedNodeStatistic nodeStatistic) {
		_positiveNodeStatistics.add(nodeStatistic.getStatIndex());
		_positiveNodeIsLog.add(false);
	}

	public void addPositiveNodeStatistics(SignedNodeStatistic nodeStatistic,
			boolean isLog) {
		_positiveNodeStatistics.add(nodeStatistic.getStatIndex());
		_positiveNodeIsLog.add(isLog);
	}

	public void addPositiveEdgeStatistics(SignedEdgeStatistic edgeStatistic) {
		_positiveEdgeStatistics.add(edgeStatistic.getStatIndex());
		_positiveEdgeIsLog.add(false);
	}

	public void addPositiveEdgeStatistics(SignedEdgeStatistic edgeStatistic,
			boolean isLog) {
		_positiveEdgeStatistics.add(edgeStatistic.getStatIndex());
		_positiveEdgeIsLog.add(isLog);
	}

	public void addNegativeNodeStatistics(SignedNodeStatistic nodeStatistic) {
		_negativeNodeStatistics.add(nodeStatistic.getStatIndex());
		_negativeNodeIsLog.add(false);
	}

	public void addNegativeNodeStatistics(SignedNodeStatistic nodeStatistic,
			boolean isLog) {
		_negativeNodeStatistics.add(nodeStatistic.getStatIndex());
		_negativeNodeIsLog.add(isLog);
	}

	public void addNegativeEdgeStatistics(SignedEdgeStatistic edgeStatistic) {
		_negativeEdgeStatistics.add(edgeStatistic.getStatIndex());
		_negativeEdgeIsLog.add(false);
	}

	public void addNegativeEdgeStatistics(SignedEdgeStatistic edgeStatistic,
			boolean isLog) {
		_negativeEdgeStatistics.add(edgeStatistic.getStatIndex());
		_negativeEdgeIsLog.add(isLog);
	}

	public void addFriendNodeStatistics(SignedNodeStatistic nodeStatistic) {
		_friendNodeStatistics.add(nodeStatistic.getStatIndex());
		_friendNodeIsLog.add(false);
	}

	public void addFriendNodeStatistics(SignedNodeStatistic nodeStatistic,
			boolean isLog) {
		_friendNodeStatistics.add(nodeStatistic.getStatIndex());
		_friendNodeIsLog.add(isLog);
	}

	public void addFriendEdgeStatistics(SignedEdgeStatistic edgeStatistic) {
		_friendEdgeStatistics.add(edgeStatistic.getStatIndex());
		_friendEdgeIsLog.add(false);
	}

	public void addFriendEdgeStatistics(SignedEdgeStatistic edgeStatistic,
			boolean isLog) {
		_friendEdgeStatistics.add(edgeStatistic.getStatIndex());
		_friendEdgeIsLog.add(isLog);
	}

	public void finalize() {
		susceptibleStatistics = new int[_susceptibleStatistics.size()];
		susceptibleIsLog = new boolean[_susceptibleIsLog.size()];
		for (int k = 0; k < _susceptibleStatistics.size(); k++) {
			susceptibleStatistics[k] = _susceptibleStatistics.get(k);
			susceptibleIsLog[k] = _susceptibleIsLog.get(k);
		}
		_susceptibleStatistics = null;
		_susceptibleIsLog = null;

		positiveNodeStatistics = new int[_positiveNodeStatistics.size()];
		positiveNodeIsLog = new boolean[_positiveNodeIsLog.size()];
		for (int k = 0; k < _positiveNodeStatistics.size(); k++) {
			positiveNodeStatistics[k] = _positiveNodeStatistics.get(k);
			positiveNodeIsLog[k] = _positiveNodeIsLog.get(k);
		}
		_positiveNodeStatistics = null;
		_positiveNodeIsLog = null;

		positiveEdgeStatistics = new int[_positiveEdgeStatistics.size()];
		positiveEdgeIsLog = new boolean[_positiveEdgeIsLog.size()];
		for (int k = 0; k < _positiveEdgeStatistics.size(); k++) {
			positiveEdgeStatistics[k] = _positiveEdgeStatistics.get(k);
			positiveEdgeIsLog[k] = _positiveEdgeIsLog.get(k);
		}
		_positiveEdgeStatistics = null;
		_positiveEdgeIsLog = null;

		negativeNodeStatistics = new int[_negativeNodeStatistics.size()];
		negativeNodeIsLog = new boolean[_negativeNodeIsLog.size()];
		for (int k = 0; k < _negativeNodeStatistics.size(); k++) {
			negativeNodeStatistics[k] = _negativeNodeStatistics.get(k);
			negativeNodeIsLog[k] = _negativeNodeIsLog.get(k);
		}
		_negativeNodeStatistics = null;
		_negativeNodeIsLog = null;

		negativeEdgeStatistics = new int[_negativeEdgeStatistics.size()];
		negativeEdgeIsLog = new boolean[_negativeEdgeIsLog.size()];
		for (int k = 0; k < _negativeEdgeStatistics.size(); k++) {
			negativeEdgeStatistics[k] = _negativeEdgeStatistics.get(k);
			negativeEdgeIsLog[k] = _negativeEdgeIsLog.get(k);
		}
		_negativeEdgeStatistics = null;
		_negativeEdgeIsLog = null;

		friendNodeStatistics = new int[_friendNodeStatistics.size()];
		friendNodeIsLog = new boolean[_friendNodeIsLog.size()];
		for (int k = 0; k < _friendNodeStatistics.size(); k++) {
			friendNodeStatistics[k] = _friendNodeStatistics.get(k);
			friendNodeIsLog[k] = _friendNodeIsLog.get(k);
		}
		_friendNodeStatistics = null;
		_friendNodeIsLog = null;

		friendEdgeStatistics = new int[_friendEdgeStatistics.size()];
		friendEdgeIsLog = new boolean[_friendEdgeIsLog.size()];
		for (int k = 0; k < _friendEdgeStatistics.size(); k++) {
			friendEdgeStatistics[k] = _friendEdgeStatistics.get(k);
			friendEdgeIsLog[k] = _friendEdgeIsLog.get(k);
		}
		_friendEdgeStatistics = null;
		_friendEdgeIsLog = null;
	}
}
