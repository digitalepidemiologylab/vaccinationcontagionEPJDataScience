package estimator;

public class EstimatorException extends Exception {

	private static final long serialVersionUID = 6312335279143156011L;

	public EstimatorException() {
		// TODO Auto-generated constructor stub
	}

	public EstimatorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EstimatorException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EstimatorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
