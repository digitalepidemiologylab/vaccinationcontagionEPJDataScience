package estimator;

import utils.ArrayUtils;

public class TimeResiduals {
	public double timeStamp;
	public double[] residuals;

	public TimeResiduals(double _timeStamp, double[] _residuals) {
		timeStamp = _timeStamp;
		residuals = new double[_residuals.length];
		ArrayUtils.copyDoubleArray(_residuals, residuals);
	}

}
